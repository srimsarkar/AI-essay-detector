# Detection Methodology

## Overview

This system detects AI-generated passages in college admissions essays at the
sentence level. The final classification is made by a trained statistical
model — not by asking a language model for its opinion.

---

## Architecture

```
User essay (text)
      │
      ▼
  Sentence Splitter (spaCy en_core_web_sm)
      │  list of {text, start_char, end_char}
      ▼
  Feature Extractor  ──────────────────────────────────┐
      ├── GPT-2 Perplexity Scorer (local, no API)       │
      ├── Burstiness Calculator                          │
      ├── Vocabulary Module (NLTK Brown corpus)          │  17 features
      ├── Style Module                                   │  per sentence
      └── Syntax Module (spaCy dependency parse)         │
                                                         │
      ▼                                                 ◄┘
  Calibrated GBT Classifier (scikit-learn)
      │  P(AI) per sentence, range [0, 1]
      ▼
  SHAP Explainer (Permutation Explainer)
      │  top-4 features driving each prediction
      ▼
  JSON response → frontend
```

---

## Feature Groups

### Group A — Perplexity (GPT-2 small, local)

| Feature | Description | AI signal |
|---------|-------------|-----------|
| `mean_log_prob` | Mean token log-probability | Higher (less surprising) |
| `perplexity` | exp(−mean_log_prob) | Lower (more predictable) |
| `min_token_prob` | Minimum per-token probability | Higher (avoids rare words) |

**Rationale:** AI generators optimize for fluency, producing text that is
highly probable under a language model prior. GPT-2 small is used as a
measurement instrument, not a judge. Its token probabilities are a
quantitative proxy for "how predictable is this text?"

### Group B — Burstiness

| Feature | Description | AI signal |
|---------|-------------|-----------|
| `perplexity_zscore` | Per-sentence perplexity relative to passage mean | Near zero |
| `passage_perplexity_std` | Std-dev of per-sentence perplexity across passage | Low |

**Rationale:** Human writing is "bursty" — some sentences are complex, others
simple. AI output maintains uniformly medium complexity. Low variance across
the passage is a strong AI signal even when individual sentence perplexity
appears normal.

### Group C — Vocabulary

| Feature | Description | AI signal |
|---------|-------------|-----------|
| `type_token_ratio` | Unique tokens / total tokens | Low (repetitive) |
| `rare_word_rate` | Fraction outside top-10K frequency | Low (common words) |
| `hedging_rate` | Coverage by AI hedging phrases | High |
| `formulaic_count` | Count of AI-characteristic phrases | High |

**Rationale:** AI output overuses transition phrases ("furthermore",
"in conclusion", "it is important to note"), avoids uncommon words, and
repeats vocabulary within a passage. The hedging phrase list contains 50+
LLM-characteristic expressions curated from GPT-3.5/Claude output analysis.

### Group D — Style

| Feature | Description | AI signal |
|---------|-------------|-----------|
| `sentence_length_tokens` | Token count | Medium, low variance |
| `sentence_length_chars` | Character count | Medium, low variance |
| `length_zscore` | Length relative to passage mean | Near zero |
| `first_person_density` | Rate of I/me/my/mine/myself | Low (avoids personal voice) |
| `punctuation_variety` | Unique punct / total punct | Low (comma-period heavy) |

### Group E — Syntax (spaCy)

| Feature | Description | AI signal |
|---------|-------------|-----------|
| `pos_entropy` | Shannon entropy of POS tag distribution | Low (uniform) |
| `dep_tree_depth` | Maximum dependency tree depth | Characteristic patterns |
| `avg_dep_tree_depth` | Mean token depth in parse tree | Characteristic patterns |

---

## Classifier

**Model:** `HistGradientBoostingClassifier` (sklearn) with
`CalibratedClassifierCV` (Platt sigmoid scaling).

**Why this model:**
- Handles correlated features and mixed-scale inputs gracefully
- Produces calibrated probability estimates (Brier score: 0.098)
- Explainable via permutation importance and SHAP

**Training data:** 320 labeled sentences — 160 authentic human sentences
(personal anecdotes, specific details, irregular structure) and 160
AI-generated sentences (formulaic transitions, abstract claims, uniform
fluency), plus 10 hybrid examples. 70/15/15 stratified split.

**Calibration:** Validated on the held-out test set. Brier score of 0.098
against a random baseline of ~0.25 confirms meaningful calibration.

---

## Evidence Generation

Per-sentence explanations use SHAP Permutation Explainer to identify which
features drove each prediction. The top-4 features by |SHAP value| are
displayed with:
- A proportional bar showing direction (toward AI or human)
- A template explanation translating the signal into plain English

This means every flag is grounded in a specific measurable property of the
text — not an LLM's unaccountable opinion.

---

## Dataset

| Source | Label | Count |
|--------|-------|-------|
| Authentic human admissions essay sentences (paraphrased/synthesised) | Human | 160 |
| GPT-2/ChatGPT-style AI essay sentences (hand-crafted and reviewed) | AI | 150 |
| AI-polished human sentences (hybrid) | AI | 10 |

All human sentences were crafted to reflect real admissions essay patterns —
specific personal anecdotes, irregular structure, genuine uncertainty.
No real student data is reproduced verbatim.
