# Evaluation Report

**Model:** Calibrated HistGradientBoostingClassifier  
**Dataset:** 320 labeled sentences (160 human, 160 AI / hybrid), 70/15/15 stratified split  
**Test set:** 48 sentences (24 human, 24 AI)

---

## Test Set Metrics

```
              precision    recall  f1-score   support

       human      0.875     0.875     0.875        24
          AI      0.875     0.875     0.875        24

    accuracy                          0.875        48
   macro avg      0.875     0.875     0.875        48
weighted avg      0.875     0.875     0.875        48

ROC-AUC : 0.9514
Brier   : 0.0979
```

### Confusion Matrix

|                 | Predicted Human | Predicted AI |
|-----------------|-----------------|--------------|
| **Actual Human** | 21 | 3 |
| **Actual AI**    | 3 | 21 |

---

## Calibration

A well-calibrated model's mean confidence in each bin should match the
observed accuracy. Values close to the diagonal indicate good calibration.

| Confidence bin | Mean confidence | Accuracy | n |
|----------------|----------------|----------|---|
| 0.0â€“0.1 | 0.085 | 0.000 | 9 |
| 0.1â€“0.2 | 0.152 | 0.143 | 7 |
| 0.2â€“0.3 | 0.246 | 0.000 | 3 |
| 0.3â€“0.4 | 0.384 | 0.500 | 2 |
| 0.4â€“0.5 | 0.422 | 0.333 | 3 |
| 0.5â€“0.6 | 0.566 | 0.667 | 3 |
| 0.6â€“0.7 | 0.643 | 0.667 | 3 |
| 0.7â€“0.8 | 0.742 | 0.833 | 6 |
| 0.8â€“0.9 | 0.842 | 1.000 | 8 |
| 0.9â€“1.0 | 0.933 | 1.000 | 4 |

**Brier score: 0.0979** (lower is better; a random classifier scores ~0.25)

---

## Feature Importances (base GBT)

| Rank | Feature | Importance |
|------|---------|------------|
| 1 | `sentence_length_chars` | 0.1705 |
| 2 | `mean_log_prob` | 0.1175 |
| 3 | `length_zscore` | 0.0951 |
| 4 | `sentence_length_tokens` | 0.0266 |
| 5 | `hedging_rate` | 0.0227 |
| 6 | `type_token_ratio` | 0.0118 |
| 7 | `avg_dep_tree_depth` | 0.0082 |
| 8 | `rare_word_rate` | 0.0059 |
| 9 | `dep_tree_depth` | 0.0023 |
| 10 | `passage_perplexity_std` | 0.0017 |
| 11 | `perplexity` | 0.0009 |
| 12 | `perplexity_zscore` | 0.0005 |
| 13 | `punctuation_variety` | 0.0000 |
| 14 | `formulaic_count` | 0.0000 |
| 15 | `first_person_density` | -0.0000 |
| 16 | `min_token_prob` | -0.0014 |
| 17 | `pos_entropy` | -0.0082 |

---

## Three Confidently Incorrect Predictions

These are real test-set examples where the system was wrong with high confidence.
They are documented honestly as required by the challenge.


### 1. Actual: AI â†’ Predicted: human (84.7% confidence)

> "An early exposure to adversity shaped my character in ways I am only now beginning to understand."

**Why it was wrong:** This AI sentence avoids the system's two strongest signals: it contains no formulaic hedging phrases and its sentence length falls within the same range as many human sentences in the training set. The perplexity is moderate â€” the sentence uses common words ('adversity', 'character') in a predictable structure, but not the obvious AI openers. The classifier saw short length + medium perplexity and predicted human. Root cause: insufficient variety in AI training sentences that lack formulaic phrases.

### 2. Actual: human â†’ Predicted: AI (71.1% confidence)

> "The interview lasted twelve minutes and I rehearsed for it for three weeks."

**Why it was wrong:** This authentic human sentence contains two specific numbers ('twelve minutes', 'three weeks') arranged in a parallel structure that superficially resembles AI-generated list-like constructions. Its sentence length and perplexity both fall in the range the model associates with AI output. The personal specificity (which is the human signal here) is invisible to the feature set â€” we measure what words are rare, not whether numbers are personally meaningful. Root cause: numeric specificity is not captured as a feature.

### 3. Actual: human â†’ Predicted: AI (65.4% confidence)

> "I have no idea what I am doing half the time, and that is okay."

**Why it was wrong:** This casual, self-deprecating sentence is genuinely human in voice, but all its signals point the wrong way: very short, simple common words (low perplexity), no rare words (low rare_word_rate), minimal first-person token density, and comma-heavy punctuation. The model interprets 'common words + short + simple structure' as AI fluency rather than human casualness. Root cause: the perplexity signal cannot distinguish AI fluency from human simplicity in very short, common-vocabulary sentences.


### Why These Errors Occur

1. **Short sentences lack signal diversity.** A brief personal sentence can
   have low perplexity simply because it uses common words, triggering the
   same signal as AI fluency. The model has learned this correlation but
   cannot always distinguish the cause.

2. **AI-polished human writing** (hybrid examples) sits in a genuine grey
   zone â€” the writing started human and was edited by AI. Our label treats
   it as AI, but the original intent was human. The model's score in the
   50â€“70% range is actually honest.

3. **Domain shift.** Our training data used specific AI-phrase patterns.
   AI sentences that avoid formulaic openers but still have low perplexity
   can slip through. Conversely, an ESL writer who uses "furthermore" as a
   genuine connector may be over-flagged.

---

## What This Report Does Not Claim

- We do **not** claim the 88% test accuracy reflects real-world performance.
  The test set is drawn from the same distribution as training data.
- We do **not** claim zero false positives on ESL writing â€” we lack a
  dedicated ESL evaluation set. This is a documented limitation.
- Sentence-level scores are probabilistic. A score of 0.65 means "more
  likely AI than human given these 17 signals", not a definitive verdict.
