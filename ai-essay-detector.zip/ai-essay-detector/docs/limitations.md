# Limitations

This document is part of the honest evaluation required by the i12 HR Drive
Hackathon challenge. We document what this system cannot do, where it will
fail, and under what circumstances it should not be trusted.

---

## 1. Training Data Distribution

The classifier was trained on 320 hand-crafted sentences that represent an
idealized contrast: stereotypically human (anecdotal, specific) vs.
stereotypically AI (formulaic, abstract). Real-world essays are more varied.

**Consequence:** The reported 88% test accuracy is an in-distribution figure.
Out-of-distribution performance is unknown and likely lower.

---

## 2. Sentence Length Dominance

Permutation importance analysis shows `sentence_length_chars` is the
single most important feature (importance: 0.17). This is a training artefact
— AI sentences in our seed data happened to cluster in a specific length range.

**Consequence:** Unusually short or long human sentences may be
misclassified regardless of content. An author who consistently writes
very long or very short sentences may receive inflated or deflated AI scores.

**Mitigation in progress:** The `length_zscore` feature is passage-relative,
which partially compensates. A future version should balance sentence lengths
in the training set.

---

## 3. ESL Writing and False Positive Risk

English as a Second Language (ESL) writers may:
- Use hedging phrases ("furthermore", "moreover") as genuine connectors
  learned from formal writing instruction
- Have lower type-token ratios due to a smaller active vocabulary
- Write shorter, simpler sentences that share perplexity characteristics
  with AI output

**This is an acknowledged evaluation gap:** We do **not** have a dedicated ESL
evaluation set. The false positive rate on ESL writing has not been empirically
measured and is unknown.

**Example risk scenario:** An ESL student writes: "Furthermore, my father
immigrated to this country when he was young, and moreover, his experience
taught me the value of hard work." The formal connectors "furthermore" and
"moreover" may trigger high `hedging_rate` and `formulaic_count` scores even
though the sentence was written by a human student who learned these transitions
from academic English instruction.

**Critical limitation:** The current system must not be interpreted as evidence
of AI authorship, especially for non-native English speakers. This detector has
not been validated on ESL writing and may systematically over-flag essays from
students whose vocabulary, sentence structure, or stylistic choices differ from
native English norms.

Users should apply extra caution when reviewing flagged essays from non-native
English speakers.

---

## 4. AI-Polished Human Writing

The challenge explicitly identifies this as the realistic deployment case.
When a human essay is passed through an AI "polish" prompt:
- Formulaic phrases may be introduced (hedging_rate increases)
- Perplexity decreases (sentences become more fluent)
- Personal voice may be retained or diluted unpredictably

The system's scores in the 50–70% range for such hybrid text are honest —
genuine ambiguity is not a failure. But the system cannot reliably
distinguish "human who writes like AI" from "AI-polished human."

---

## 5. Very Short Essays / Sentences

Burstiness features (`passage_perplexity_std`, `length_zscore`) require
multiple sentences for meaningful signal. A one-sentence submission or a
submission with only two sentences will have degenerate burstiness scores.

**Consequence:** Very short essays will rely disproportionately on
single-sentence features, increasing variance in predictions.

---

## 6. GPT-2 as Measurement Instrument

GPT-2 small (117M parameters) is used to measure token probabilities.
Its probability estimates differ from those of a modern LLM. Text generated
by GPT-4 or Claude may appear surprisingly high-perplexity under GPT-2 if
the modern model uses sophisticated vocabulary that GPT-2 finds unusual.

**Consequence:** Sophisticated AI-generated essays that avoid the obvious
formulaic patterns may partially evade detection via the perplexity signals.
The vocabulary and style signals provide complementary coverage.

---

## 7. Sentence Splitter Dependency

Sentence-level scores depend on accurate sentence boundary detection.
Unusual punctuation (em-dashes, semicolons used as sentence breaks, poetry
formatting) may cause mis-segmentation, merging or splitting sentences in
ways that corrupt feature values.

---

## 8. No Ground-Truth Probability

"AI-generated" is not a binary property in practice — it exists on a
continuum from fully human, through AI-assisted, to fully AI-generated.
Our binary labels create an artificial decision boundary. The calibrated
probability output (0–100%) is more meaningful than a binary verdict.

**Recommendation:** Do not use this tool to make final admissions decisions.
Use it as one signal among many, and always apply human judgment to scores
in the 35–65% range.

---

## 9. What This System Is Not

- It is **not** a plagiarism detector
- It is **not** a detector of AI-generated images, code, or structured data
- It is **not** a forensic tool suitable for disciplinary proceedings
- It does **not** identify *which* AI system generated text
- Its output is **not** admissible evidence of academic dishonesty
