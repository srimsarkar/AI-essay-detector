"""
Dataset builder.

Reads labeled sentences from seed_data.py, runs the full feature
extraction pipeline on each sentence, and saves the result to
data/processed/features.npz.

Usage (from repo root):
    python -m training.build_dataset

Output
------
data/processed/features.npz  with arrays:
    X            : float32 (n_samples, n_features)
    y            : int8    (n_samples,)   0=human, 1=AI
    feature_names: str     (n_features,)
    split        : str     (n_samples,)   "train" | "val" | "test"
"""
from __future__ import annotations

import os
import sys
import logging
import random

import numpy as np

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("build_dataset")

# ── Resolve paths ─────────────────────────────────────────────────────────────
_HERE = os.path.dirname(__file__)
_BACKEND = os.path.abspath(os.path.join(_HERE, ".."))
_REPO_ROOT = os.path.abspath(os.path.join(_BACKEND, ".."))
_DATA_PROCESSED = os.path.join(_REPO_ROOT, "data", "processed")

if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)


def main(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)

    # ── Load seed data ────────────────────────────────────────────────────
    from training.seed_data import HUMAN_SENTENCES, AI_SENTENCES, HYBRID_SENTENCES

    # Build sentence list and labels
    sentences: list[str] = []
    labels: list[int] = []

    for s in HUMAN_SENTENCES:
        s = s.strip()
        if s:
            sentences.append(s)
            labels.append(0)

    for s in AI_SENTENCES:
        s = s.strip()
        if s:
            sentences.append(s)
            labels.append(1)

    for s in HYBRID_SENTENCES:
        s = s.strip()
        if s:
            sentences.append(s)
            labels.append(1)   # treated as AI-influenced

    logger.info("Total sentences: %d  (human=%d, AI=%d)",
                len(sentences),
                sum(1 for l in labels if l == 0),
                sum(1 for l in labels if l == 1))

    # ── Shuffle ───────────────────────────────────────────────────────────
    combined = list(zip(sentences, labels))
    random.shuffle(combined)
    sentences, labels = zip(*combined)
    sentences = list(sentences)
    labels = list(labels)

    # ── Extract features ──────────────────────────────────────────────────
    # We run the extractor sentence-by-sentence via the pipeline.
    # The extractor expects a list of {"text", "start", "end"} dicts.
    from pipeline.extractor import extract_features

    logger.info("Extracting features — this will take several minutes (GPT-2 scoring)…")

    all_features = []
    feature_names_out: list[str] = []

    # Process in batches to avoid one giant GPT-2 call
    BATCH = 32
    n = len(sentences)
    for start in range(0, n, BATCH):
        batch_sents = sentences[start:start + BATCH]
        sent_dicts = [{"text": s, "start": 0, "end": len(s)} for s in batch_sents]
        feats, feat_names = extract_features(sent_dicts)
        all_features.append(feats)
        if not feature_names_out:
            feature_names_out = feat_names
        if (start // BATCH) % 5 == 0:
            logger.info("  processed %d / %d sentences…", min(start + BATCH, n), n)

    X = np.vstack(all_features).astype(np.float32)
    y = np.array(labels, dtype=np.int8)

    logger.info("Feature matrix: %s  labels: %s", X.shape, y.shape)

    # ── Sanitise: replace NaN/Inf ─────────────────────────────────────────
    bad = ~np.isfinite(X)
    if bad.any():
        logger.warning("Replacing %d non-finite values with 0", bad.sum())
        X = np.where(bad, 0.0, X)

    # ── Train / val / test split (70 / 15 / 15), stratified ──────────────
    split_labels = _stratified_split(y, seed=seed)

    # ── Save ──────────────────────────────────────────────────────────────
    os.makedirs(_DATA_PROCESSED, exist_ok=True)
    out_path = os.path.join(_DATA_PROCESSED, "features.npz")
    np.savez(
        out_path,
        X=X,
        y=y,
        feature_names=np.array(feature_names_out, dtype=object),
        split=np.array(split_labels, dtype=object),
    )
    logger.info("Saved → %s", out_path)
    _report_split(y, split_labels)


def _stratified_split(y: np.ndarray, seed: int = 42,
                      train_frac: float = 0.70,
                      val_frac: float = 0.15) -> list[str]:
    """
    Stratified split into train / val / test.
    Returns a list of split labels aligned with y.
    """
    rng = np.random.default_rng(seed)
    n = len(y)
    splits = [""] * n

    for cls in [0, 1]:
        idx = np.where(y == cls)[0]
        idx = rng.permutation(idx)
        n_cls = len(idx)
        n_train = int(n_cls * train_frac)
        n_val = int(n_cls * val_frac)
        for i in idx[:n_train]:
            splits[i] = "train"
        for i in idx[n_train:n_train + n_val]:
            splits[i] = "val"
        for i in idx[n_train + n_val:]:
            splits[i] = "test"

    return splits


def _report_split(y: np.ndarray, splits: list[str]) -> None:
    for part in ["train", "val", "test"]:
        idx = [i for i, s in enumerate(splits) if s == part]
        if idx:
            part_y = y[idx]
            logger.info("  %s: %d total  (human=%d, AI=%d)",
                        part, len(idx),
                        int((part_y == 0).sum()),
                        int((part_y == 1).sum()))


if __name__ == "__main__":
    main()
