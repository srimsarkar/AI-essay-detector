"""
Classifier training script.

Loads data/processed/features.npz, trains a calibrated Gradient Boosted
Trees classifier (sklearn HistGradientBoostingClassifier with
CalibratedClassifierCV), and saves the model to backend/models/classifier.pkl.

Why HistGradientBoosting?
-------------------------
- Handles missing / zero-padded features gracefully (native NaN support)
- Fast on CPU
- Produces well-calibrated probability estimates after Platt scaling
- Explainable via SHAP TreeExplainer

Usage (from repo root):
    python -m training.train
"""
from __future__ import annotations

import os
import sys
import pickle
import logging

import numpy as np

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("train")

_HERE = os.path.dirname(__file__)
_BACKEND = os.path.abspath(os.path.join(_HERE, ".."))
_REPO_ROOT = os.path.abspath(os.path.join(_BACKEND, ".."))
_DATA_PROCESSED = os.path.join(_REPO_ROOT, "data", "processed")
_MODELS_DIR = os.path.join(_BACKEND, "models")

if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)


def main() -> None:
    # ── Load dataset ──────────────────────────────────────────────────────
    features_path = os.path.join(_DATA_PROCESSED, "features.npz")
    if not os.path.exists(features_path):
        raise FileNotFoundError(
            f"Feature matrix not found at {features_path}. "
            "Run `python -m training.build_dataset` first."
        )

    data = np.load(features_path, allow_pickle=True)
    X = data["X"].astype(np.float32)
    y = data["y"].astype(int)
    feature_names = list(data["feature_names"])
    splits = list(data["split"])

    logger.info("Loaded: X=%s  y=%s  features=%s", X.shape, y.shape, feature_names)

    # ── Split ─────────────────────────────────────────────────────────────
    train_idx = [i for i, s in enumerate(splits) if s == "train"]
    val_idx   = [i for i, s in enumerate(splits) if s == "val"]
    test_idx  = [i for i, s in enumerate(splits) if s == "test"]

    X_train, y_train = X[train_idx], y[train_idx]
    X_val,   y_val   = X[val_idx],   y[val_idx]
    X_test,  y_test  = X[test_idx],  y[test_idx]

    logger.info("Train=%d  Val=%d  Test=%d", len(y_train), len(y_val), len(y_test))

    # ── Feature scaling ───────────────────────────────────────────────────
    # HistGBT doesn't need scaling, but downstream SHAP and Logistic
    # Regression benefit from it.  We scale for consistency.
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s   = scaler.transform(X_val)
    X_test_s  = scaler.transform(X_test)

    # ── Train primary model ───────────────────────────────────────────────
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.calibration import CalibratedClassifierCV
    from sklearn.frozen import FrozenEstimator

    logger.info("Training HistGradientBoostingClassifier…")
    base = HistGradientBoostingClassifier(
        max_iter=200,
        max_depth=4,
        min_samples_leaf=5,
        learning_rate=0.05,
        random_state=42,
    )

    # Fit base model on training set, then calibrate on val set.
    # Using FrozenEstimator avoids the cv='prefit' deprecation warning in sklearn 1.6+.
    base.fit(X_train_s, y_train)
    logger.info("Base model val accuracy: %.3f", base.score(X_val_s, y_val))

    try:
        calibrated = CalibratedClassifierCV(FrozenEstimator(base), method="sigmoid")
    except ImportError:
        # sklearn < 1.6 fallback
        calibrated = CalibratedClassifierCV(base, cv="prefit", method="sigmoid")
    calibrated.fit(X_val_s, y_val)

    # ── Evaluate on val set ───────────────────────────────────────────────
    from sklearn.metrics import (
        classification_report, roc_auc_score, brier_score_loss
    )

    y_pred     = calibrated.predict(X_val_s)
    y_prob     = calibrated.predict_proba(X_val_s)[:, 1]

    logger.info("=== Validation set ===")
    logger.info("\n%s", classification_report(y_val, y_pred, target_names=["human", "AI"]))
    logger.info("ROC-AUC : %.3f", roc_auc_score(y_val, y_prob))
    logger.info("Brier   : %.3f", brier_score_loss(y_val, y_prob))

    # ── Evaluate on test set (hold-out) ───────────────────────────────────
    y_pred_t = calibrated.predict(X_test_s)
    y_prob_t = calibrated.predict_proba(X_test_s)[:, 1]

    logger.info("=== Test set (held-out) ===")
    logger.info("\n%s", classification_report(y_test, y_pred_t, target_names=["human", "AI"]))
    if len(np.unique(y_test)) > 1:
        logger.info("ROC-AUC : %.3f", roc_auc_score(y_test, y_prob_t))
        logger.info("Brier   : %.3f", brier_score_loss(y_test, y_prob_t))

    # ── Save model bundle ─────────────────────────────────────────────────
    os.makedirs(_MODELS_DIR, exist_ok=True)
    model_path = os.path.join(_MODELS_DIR, "classifier.pkl")
    bundle = {
        "model": calibrated,
        "scaler": scaler,
        "feature_names": feature_names,
    }
    with open(model_path, "wb") as f:
        pickle.dump(bundle, f)
    logger.info("Model saved → %s", model_path)


if __name__ == "__main__":
    main()
