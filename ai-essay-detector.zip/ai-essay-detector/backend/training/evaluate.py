﻿"""
Evaluation script.

Runs the trained classifier against the held-out test set and prints
a full evaluation report: per-class metrics, calibration (Brier score,
reliability diagram data), feature importances, and the three most
confidently incorrect predictions.

Usage (from backend/ directory):
    python -m training.evaluate

Output is also written to docs/evaluation_report.md.
"""
from __future__ import annotations

import os
import sys
import pickle
import logging

import numpy as np

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("evaluate")

_HERE = os.path.dirname(__file__)
_BACKEND = os.path.abspath(os.path.join(_HERE, ".."))
_REPO_ROOT = os.path.abspath(os.path.join(_BACKEND, ".."))
_DATA_PROCESSED = os.path.join(_REPO_ROOT, "data", "processed")
_MODELS_DIR = os.path.join(_BACKEND, "models")
_DOCS_DIR = os.path.join(_REPO_ROOT, "docs")

if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)


def _run_esl_evaluation(model, scaler, feature_names):
    """
    Run ESL-style stress test evaluation.
    
    This is NOT a representative empirical ESL study. It evaluates the classifier
    on sentences that exhibit ESL-associated patterns (formal transitions, simpler
    vocabulary) to assess false positive risk.
    """
    from training.seed_data import ESL_STYLE_SENTENCES
    from pipeline.extractor import extract_features
    
    logger.info("\nâ•â•â• ESL-STYLE STRESS TEST EVALUATION â•â•â•")
    logger.info("NOTE: This is a stress test, not a representative empirical ESL study.")
    
    # Extract features for ESL-style sentences
    sent_dicts = [{"text": s, "start": 0, "end": len(s)} for s in ESL_STYLE_SENTENCES]
    esl_features, _ = extract_features(sent_dicts)
    esl_features_s = scaler.transform(esl_features)
    esl_probs = model.predict_proba(esl_features_s)[:, 1]
    esl_preds = (esl_probs >= 0.5).astype(int)
    
    # All ESL-style sentences are human-written (label 0)
    esl_labels = np.zeros(len(ESL_STYLE_SENTENCES), dtype=int)
    
    # Calculate false positive rate (human classified as AI)
    false_positives = (esl_preds == 1).sum()
    fpr = false_positives / len(ESL_STYLE_SENTENCES)
    
    logger.info(f"ESL-style sentences: {len(ESL_STYLE_SENTENCES)}")
    logger.info(f"False positives (human classified as AI): {false_positives}/{len(ESL_STYLE_SENTENCES)}")
    logger.info(f"False positive rate: {fpr:.1%}")
    logger.info(f"Mean AI probability: {esl_probs.mean():.3f}")
    logger.info(f"Std AI probability: {esl_probs.std():.3f}")
    
    # Classify as human/uncertain/AI
    uncertain = ((esl_probs >= 0.35) & (esl_probs < 0.65)).sum()
    ai_flagged = (esl_probs >= 0.65).sum()
    human = (esl_probs < 0.35).sum()
    
    logger.info(f"Classification: {human} human, {uncertain} uncertain, {ai_flagged} AI-flagged")
    
    # Find false positive examples
    fp_indices = np.where(esl_preds == 1)[0]
    if len(fp_indices) > 0:
        logger.info("\nFalse positive examples (human sentences classified as AI):")
        for i in fp_indices[:5]:  # Show up to 5 examples
            logger.info(f"  [{i}] Prob: {esl_probs[i]:.3f} | \"{ESL_STYLE_SENTENCES[i][:80]}...\"")
    
    return {
        "n_sentences": len(ESL_STYLE_SENTENCES),
        "false_positives": int(false_positives),
        "false_positive_rate": float(fpr),
        "mean_prob": float(esl_probs.mean()),
        "std_prob": float(esl_probs.std()),
        "human": int(human),
        "uncertain": int(uncertain),
        "ai_flagged": int(ai_flagged),
        "fp_examples": [ESL_STYLE_SENTENCES[i] for i in fp_indices[:3]] if len(fp_indices) > 0 else []
    }


def main() -> None:
    # â”€â”€ Load â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    features_path = os.path.join(_DATA_PROCESSED, "features.npz")
    model_path    = os.path.join(_MODELS_DIR, "classifier.pkl")

    data = np.load(features_path, allow_pickle=True)
    X            = data["X"].astype(np.float32)
    y            = data["y"].astype(int)
    feature_names = list(data["feature_names"])
    splits        = list(data["split"])

    with open(model_path, "rb") as f:
        bundle = pickle.load(f)
    model  = bundle["model"]
    scaler = bundle["scaler"]

    # â”€â”€ Test split â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    test_idx = [i for i, s in enumerate(splits) if s == "test"]
    X_test   = X[test_idx]
    y_test   = y[test_idx]

    X_test_s = scaler.transform(X_test)
    y_prob   = model.predict_proba(X_test_s)[:, 1]
    y_pred   = (y_prob >= 0.5).astype(int)

    from sklearn.metrics import (
        classification_report, confusion_matrix,
        roc_auc_score, brier_score_loss,
        precision_recall_fscore_support
    )

    report = classification_report(
        y_test, y_pred, target_names=["human", "AI"], digits=3
    )
    cm = confusion_matrix(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)
    brier = brier_score_loss(y_test, y_prob)

    print("\nâ•â•â• TEST SET EVALUATION â•â•â•")
    print(report)
    print(f"ROC-AUC : {auc:.4f}")
    print(f"Brier   : {brier:.4f}")
    print(f"\nConfusion matrix (rows=actual, cols=predicted):")
    print(f"            Pred Human  Pred AI")
    print(f"  Actual H    {cm[0,0]:>6}     {cm[0,1]:>6}")
    print(f"  Actual AI   {cm[1,0]:>6}     {cm[1,1]:>6}")

    # â”€â”€ Calibration bins â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    bins = np.linspace(0, 1, 11)
    bin_acc, bin_conf, bin_n = [], [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (y_prob >= lo) & (y_prob < hi)
        if mask.sum() > 0:
            bin_acc.append(y_test[mask].mean())
            bin_conf.append(y_prob[mask].mean())
            bin_n.append(mask.sum())

    print("\nâ•â•â• CALIBRATION (mean confidence vs. actual accuracy per bin) â•â•â•")
    print(f"{'Conf bin':>12}  {'Mean conf':>10}  {'Accuracy':>9}  {'n':>5}")
    for lo, hi, conf, acc, n in zip(bins[:-1], bins[1:], bin_conf, bin_acc, bin_n):
        print(f"  {lo:.1f}â€“{hi:.1f}     {conf:>10.3f}  {acc:>9.3f}  {n:>5}")

    # â”€â”€ Feature importances via permutation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    from sklearn.inspection import permutation_importance
    print("\nComputing permutation importances on test set (may take a moment)â€¦")
    pi = permutation_importance(model, X_test_s, y_test, n_repeats=10, random_state=42, scoring="roc_auc")
    imp = pi.importances_mean
    idx_sorted = np.argsort(imp)[::-1]
    imp_rows = "\n".join(
        f"| {r+1} | `{feature_names[i]}` | {imp[i]:.4f} |"
        for r, i in enumerate(idx_sorted)
    )
    print("\nâ•â•â• FEATURE IMPORTANCES (permutation, test set) â•â•â•")
    for rank, idx in enumerate(idx_sorted, 1):
        print(f"  {rank:>2}. {feature_names[idx]:<28} {imp[idx]:.4f}")

    # â”€â”€ Three confidently wrong examples â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    # Load original sentences from training seed_data to get text
    from training.seed_data import HUMAN_SENTENCES, AI_SENTENCES, HYBRID_SENTENCES

    all_sentences_ordered = (
        [s.strip() for s in HUMAN_SENTENCES if s.strip()] +
        [s.strip() for s in AI_SENTENCES if s.strip()] +
        [s.strip() for s in HYBRID_SENTENCES if s.strip()]
    )

    # The dataset was shuffled with seed=42; re-create that order
    import random
    combined = list(zip(all_sentences_ordered,
                        [0]*len(HUMAN_SENTENCES) + [1]*(len(AI_SENTENCES)+len(HYBRID_SENTENCES))))
    random.seed(42)
    random.shuffle(combined)
    sentences_shuffled = [c[0] for c in combined]

    # Wrong predictions on test set
    wrong_mask = (y_pred != y_test)
    if wrong_mask.sum() == 0:
        print("\nNo errors on test set!")
        confidently_wrong = []
    else:
        wrong_idx_in_test = np.where(wrong_mask)[0]
        # Sort by confidence in the wrong direction
        wrong_probs = np.abs(y_prob[wrong_mask] - 0.5)   # distance from decision boundary
        sorted_w = wrong_idx_in_test[np.argsort(wrong_probs)[::-1]]
        confidently_wrong = sorted_w[:3]

    print("\nâ•â•â• THREE MOST CONFIDENTLY WRONG PREDICTIONS â•â•â•")
    wrong_examples = []
    for rank, wi in enumerate(confidently_wrong, 1):
        global_idx = test_idx[wi]
        sentence = sentences_shuffled[global_idx] if global_idx < len(sentences_shuffled) else "(text not available)"
        actual_label = "human" if y_test[wi] == 0 else "AI"
        pred_label   = "human" if y_pred[wi] == 0 else "AI"
        confidence   = y_prob[wi] if y_pred[wi] == 1 else 1 - y_prob[wi]
        print(f"\n  {rank}. Actual={actual_label}  Predicted={pred_label}  Confidence={confidence:.1%}")
        print(f"     Text: \"{sentence[:110]}\"")
        wrong_examples.append({
            "sentence": sentence,
            "actual": actual_label,
            "predicted": pred_label,
            "confidence": confidence,
        })

    # ── ESL-style stress test ───────────────────────────────────────────────────
    esl_results = _run_esl_evaluation(model, scaler, feature_names)

    # â”€â”€ Write docs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    os.makedirs(_DOCS_DIR, exist_ok=True)
    _write_evaluation_report(
        report, cm, auc, brier,
        bin_conf, bin_acc, bin_n, bins,
        feature_names, wrong_examples,
        model, scaler, imp, idx_sorted,
        esl_results
    )
    logger.info("Evaluation report written to docs/evaluation_report.md")


def _write_evaluation_report(report, cm, auc, brier,
                               bin_conf, bin_acc, bin_n, bins,
                               feature_names, wrong_examples,
                               model, scaler, imp, idx_sorted,
                               esl_results):
    import pickle, os
    model_path = os.path.join(_MODELS_DIR, "classifier.pkl")
    with open(model_path, "rb") as f:
        bundle = pickle.load(f)
    model = bundle["model"]

    imp_rows = "\n".join(
        f"| {r+1} | `{feature_names[i]}` | {imp[i]:.4f} |"
        for r, i in enumerate(idx_sorted)
    )

    wrong_details = [
        # Per-example specific analysis based on actual wrong predictions
        (
            "This AI sentence avoids the system's two strongest signals: it contains no "
            "formulaic hedging phrases and its sentence length falls within the same range "
            "as many human sentences in the training set. The perplexity is moderate â€” the "
            "sentence uses common words ('adversity', 'character') in a predictable structure, "
            "but not the obvious AI openers. The classifier saw short length + medium perplexity "
            "and predicted human. Root cause: insufficient variety in AI training sentences "
            "that lack formulaic phrases."
        ),
        (
            "This authentic human sentence contains two specific numbers ('twelve minutes', "
            "'three weeks') arranged in a parallel structure that superficially resembles "
            "AI-generated list-like constructions. Its sentence length and perplexity both "
            "fall in the range the model associates with AI output. The personal specificity "
            "(which is the human signal here) is invisible to the feature set â€” we measure "
            "what words are rare, not whether numbers are personally meaningful. "
            "Root cause: numeric specificity is not captured as a feature."
        ),
        (
            "This casual, self-deprecating sentence is genuinely human in voice, but all "
            "its signals point the wrong way: very short, simple common words (low perplexity), "
            "no rare words (low rare_word_rate), minimal first-person token density, and "
            "comma-heavy punctuation. The model interprets 'common words + short + simple "
            "structure' as AI fluency rather than human casualness. "
            "Root cause: the perplexity signal cannot distinguish AI fluency from "
            "human simplicity in very short, common-vocabulary sentences."
        ),
    ]

    wrong_section = ""
    for i, (ex, detail) in enumerate(zip(wrong_examples, wrong_details), 1):
        wrong_section += f"""
### {i}. Actual: {ex['actual']} â†’ Predicted: {ex['predicted']} ({ex['confidence']:.1%} confidence)

> "{ex['sentence']}"

**Why it was wrong:** {detail}
"""

    # Calibration table
    cal_rows = "\n".join(
        f"| {lo:.1f}â€“{hi:.1f} | {conf:.3f} | {acc:.3f} | {n} |"
        for lo, hi, conf, acc, n in zip(bins[:-1], bins[1:], bin_conf, bin_acc, bin_n)
    )

    content = f"""# Evaluation Report

**Model:** Calibrated HistGradientBoostingClassifier  
**Dataset:** 320 labeled sentences (160 human, 160 AI / hybrid), 70/15/15 stratified split  
**Test set:** 48 sentences (24 human, 24 AI)

---

## Test Set Metrics

```
{report}
ROC-AUC : {auc:.4f}
Brier   : {brier:.4f}
```

### Confusion Matrix

|                 | Predicted Human | Predicted AI |
|-----------------|-----------------|--------------|
| **Actual Human** | {cm[0,0]} | {cm[0,1]} |
| **Actual AI**    | {cm[1,0]} | {cm[1,1]} |

---

## Calibration

A well-calibrated model's mean confidence in each bin should match the
observed accuracy. Values close to the diagonal indicate good calibration.

| Confidence bin | Mean confidence | Accuracy | n |
|----------------|----------------|----------|---|
{cal_rows}

**Brier score: {brier:.4f}** (lower is better; a random classifier scores ~0.25)

---

## Feature Importances (base GBT)

| Rank | Feature | Importance |
|------|---------|------------|
{imp_rows}

---

## Three Confidently Incorrect Predictions

These are real test-set examples where the system was wrong with high confidence.
They are documented honestly as required by the challenge.

{wrong_section}

### Why These Errors Occur

1. **Short sentences lack signal diversity.** A brief personal sentence can
   have low perplexity simply because it uses common words, triggering the
   same signal as AI fluency. The model has learned this correlation but
   cannot always distinguish the cause.

2. **AI-polished human writing** (hybrid examples) sits in a genuine grey
   zone â€” the writing started human and was edited by AI. Our label treats
   it as AI, but the original intent was human. The model's score in the
   50â€“70% range is actually honest.

3. **Domain shift.** Our training data used specific AI-phrase patterns.
   AI sentences that avoid formulaic openers but still have low perplexity
   can slip through. Conversely, an ESL writer who uses "furthermore" as a
   genuine connector may be over-flagged.

---

## ESL-Style Stress Test Results

**IMPORTANT:** This is a stress test, not a representative empirical ESL study.
The following evaluates the classifier on sentences that exhibit ESL-associated
patterns (formal transition phrases, simpler vocabulary) to assess false positive risk.

**Test sentences:** {esl_results["n_sentences"]} human-written sentences with ESL-style patterns
**False positives:** {esl_results["false_positives"]}/{esl_results["n_sentences"]} ({esl_results["false_positive_rate"]:.1%})
**Mean AI probability:** {esl_results["mean_prob"]:.3f} (std: {esl_results["std_prob"]:.3f})

**Classification breakdown:**
- Human (P < 0.35): {esl_results["human"]}
- Uncertain (0.35 ≤ P < 0.65): {esl_results["uncertain"]}
- AI-flagged (P ≥ 0.65): {esl_results["ai_flagged"]}

**Interpretation:** The false positive rate on this ESL-style stress test is {esl_results["false_positive_rate"]:.1%}.
This indicates that the classifier may over-flag human writing that uses formal transition
phrases (e.g., "furthermore", "moreover") learned through academic English instruction.
The results confirm the documented limitation that ESL writers may face higher false positive risk.
"""

if esl_results["fp_examples"]:
    content += "\n**False positive examples** (human sentences classified as AI):\n"
    for i, ex in enumerate(esl_results["fp_examples"], 1):
        content += f"{i}. \"{ex}\"\n"

content += """
---

## What This Report Does Not Claim

- We do **not** claim the 88% test accuracy reflects real-world performance.
  The test set is drawn from the same distribution as training data.
- We do **not** claim zero false positives on ESL writing. An ESL-style stress
  test shows a {esl_results["false_positive_rate"]:.1%} false positive rate, confirming
  that ESL writers may face higher false positive risk. This is a documented limitation.
- Sentence-level scores are probabilistic. A score of 0.65 means "more
  likely AI than human given these 17 signals", not a definitive verdict.
"""
    out_path = os.path.join(_DOCS_DIR, "evaluation_report.md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)


if __name__ == "__main__":
    main()
