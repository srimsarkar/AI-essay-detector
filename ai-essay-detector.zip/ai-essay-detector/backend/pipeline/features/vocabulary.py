"""
Vocabulary / lexical feature module.

Features per sentence
---------------------
type_token_ratio  : unique tokens / total tokens (lowercased, alpha-only)
                    Low TTR can indicate repetitive AI phrasing.
rare_word_rate    : fraction of words outside the top-10K English frequency list.
                    AI tends to use common, safe vocabulary; unusual rate may
                    indicate human specificity OR (confusingly) AI verbosity.
                    Used in combination with other signals.
hedging_rate      : fraction of tokens that overlap with known AI hedging /
                    formulaic phrases.  AI overuses transition phrases.
formulaic_count   : raw count of AI-favored cliché phrases detected in sentence.

Notes on ESL awareness
-----------------------
TTR can be low for ESL writers who reuse a smaller vocabulary — this is why
we use it as one signal among many rather than a standalone indicator.
The hedging phrase list is tuned to AI output specifically (e.g. "delve into",
"it is important to note") rather than generic English formality.
"""
from __future__ import annotations

import re
import string
from functools import lru_cache

FEATURE_NAMES = ["type_token_ratio", "rare_word_rate", "hedging_rate", "formulaic_count"]

# ── Hedging / formulaic AI phrases ────────────────────────────────────────────
# Lowercased multi-word phrases characteristic of AI-generated text.
# Source: curated from analysis of ChatGPT/Claude output patterns.
HEDGING_PHRASES: list[str] = [
    # Transition openers
    "in conclusion",
    "in summary",
    "to summarize",
    "in essence",
    "to conclude",
    "in closing",
    "in a nutshell",
    # Meta-commentary
    "it is important to note",
    "it is worth noting",
    "it should be noted",
    "it is imperative",
    "it goes without saying",
    "needless to say",
    "as previously mentioned",
    "as mentioned above",
    "as noted earlier",
    # Filler connectives
    "furthermore",
    "moreover",
    "additionally",
    "in addition to",
    "last but not least",
    # AI-characteristic vocabulary
    "delve into",
    "delve deeper",
    "tapestry",
    "the intersection of",
    "at its core",
    "a testament to",
    "commendable",
    "invaluable",
    "multifaceted",
    "in today's society",
    "in today's world",
    "in the modern world",
    "as an ai",
    "as a language model",
    "the realm of",
    "crucial role",
    "play a pivotal role",
    "transformative",
    "foster a sense",
    "foster growth",
    "underscores the importance",
    "highlights the importance",
    "it is crucial",
    "it is essential",
    "embark on",
    "navigate the complexities",
    "stands as a testament",
    "not only but also",
    "in order to",
    "with that being said",
    "that being said",
    "on the other hand",
    "in light of",
    "it is evident",
    "it is clear",
    "it is apparent",
]

# Build a sorted-by-length-desc list for greedy matching
_SORTED_PHRASES = sorted(HEDGING_PHRASES, key=len, reverse=True)


# ── Top-10K word list (compact) ───────────────────────────────────────────────
# Rather than ship a file, we load the NLTK corpus words and keep top common ones.
# As a fast fallback we hardcode a set of ~2000 very common English words.
# The full approach uses NLTK's brown corpus word frequencies.

@lru_cache(maxsize=1)
def _get_common_words() -> frozenset[str]:
    """
    Return a frozenset of the top ~10 000 most common English words (lowercase).
    Uses NLTK Brown corpus frequencies; falls back to a bundled 2000-word set.
    """
    try:
        import nltk
        from nltk.corpus import brown

        # Ensure corpus is available
        try:
            brown.words()
        except LookupError:
            nltk.download("brown", quiet=True)

        from collections import Counter
        freq = Counter(w.lower() for w in brown.words() if w.isalpha())
        top = frozenset(w for w, _ in freq.most_common(10_000))
        return top
    except Exception:
        # Minimal hardcoded fallback (~300 most common function + content words)
        return frozenset(_FALLBACK_COMMON_WORDS)


# Very small fallback list (used only if NLTK Brown corpus is unavailable)
_FALLBACK_COMMON_WORDS = {
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "it",
    "for", "not", "on", "with", "he", "as", "you", "do", "at", "this",
    "but", "his", "by", "from", "they", "we", "say", "her", "she", "or",
    "an", "will", "my", "one", "all", "would", "there", "their", "what",
    "so", "up", "out", "if", "about", "who", "get", "which", "go", "me",
    "when", "make", "can", "like", "time", "no", "just", "him", "know",
    "take", "people", "into", "year", "your", "good", "some", "could",
    "them", "see", "other", "than", "then", "now", "look", "only", "come",
    "its", "over", "think", "also", "back", "after", "use", "two", "how",
    "our", "work", "first", "well", "way", "even", "new", "want", "because",
    "any", "these", "give", "day", "most", "us", "great", "between", "need",
    "large", "often", "hand", "high", "place", "hold", "turn", "was", "were",
    "been", "has", "had", "did", "said", "each", "which", "their", "time",
    "i", "am", "is", "are", "very", "more", "such", "may", "much", "before",
    "life", "man", "world", "long", "little", "own", "old", "right", "big",
    "different", "same", "too", "feel", "help", "put", "keep", "let", "begin",
    "seem", "show", "hear", "play", "run", "move", "live", "believe", "hold",
    "bring", "happen", "write", "provide", "sit", "stand", "lose", "pay",
    "meet", "include", "continue", "set", "learn", "change", "lead", "under",
    "never", "here", "why", "ask", "went", "men", "read", "need", "land",
    "different", "home", "move", "try", "kind", "hand", "picture", "again",
    "change", "off", "play", "spell", "air", "away", "animal", "house",
    "point", "page", "letter", "mother", "answer", "found", "study", "still",
    "learn", "plant", "cover", "food", "sun", "four", "between", "state",
    "keep", "eye", "never", "last", "let", "thought", "city", "tree", "cross",
    "farm", "hard", "start", "might", "story", "saw", "far", "sea", "draw",
    "left", "late", "run", "while", "press", "close", "night", "real", "open",
    "seem", "together", "next", "white", "children", "begin", "got", "walk",
    "example", "ease", "paper", "group", "always", "music", "those", "both",
    "mark", "book", "carry", "took", "science", "eat", "room", "friend",
    "began", "idea", "fish", "mountain", "stop", "once", "base", "hear",
    "horse", "cut", "sure", "watch", "color", "face", "wood", "main", "enough",
    "plain", "girl", "usual", "young", "ready", "above", "ever", "red", "list",
    "though", "feel", "talk", "bird", "soon", "body", "dog", "family", "direct",
    "pose", "leave", "song", "measure", "door", "product", "black", "short",
    "numeral", "class", "wind", "question", "happen", "complete", "ship", "area",
    "half", "rock", "order", "fire", "south", "problem", "piece", "told",
    "knew", "pass", "since", "top", "whole", "king", "space", "heard", "best",
    "hour", "better", "true", "during", "hundred", "five", "remember", "step",
    "early", "hold", "west", "ground", "interest", "reach", "fast", "listen",
    "six", "table", "travel", "less", "morning", "ten", "simple", "several",
    "vowel", "toward", "war", "lay", "against", "pattern", "slow", "center",
    "love", "person", "money", "serve", "appear", "road", "map", "rain",
    "rule", "govern", "pull", "cold", "notice", "voice", "unit", "power",
    "town", "fine", "drive", "deep", "clean", "plan", "spoke", "behind",
    "cannot", "done", "clear", "machine", "line", "rest", "decide", "rather",
    "choose", "knew", "able", "river", "glad", "exactly", "region", "meant",
    "force", "type", "star", "joy", "glad", "natural",
}


# ── Public API ────────────────────────────────────────────────────────────────

def score_sentence(sentence: str) -> dict:
    """
    Compute vocabulary / lexical features for a single sentence.

    Parameters
    ----------
    sentence : raw sentence string

    Returns
    -------
    Dict with keys matching FEATURE_NAMES.
    """
    if not sentence or not sentence.strip():
        return {k: 0.0 for k in FEATURE_NAMES}

    lower = sentence.lower()

    # ── Tokenise (alpha words only) ───────────────────────────────────────
    words = [w for w in re.findall(r"[a-z]+", lower)]
    n_words = len(words)

    if n_words == 0:
        return {k: 0.0 for k in FEATURE_NAMES}

    # ── Type-Token Ratio ──────────────────────────────────────────────────
    ttr = len(set(words)) / n_words

    # ── Rare word rate ────────────────────────────────────────────────────
    common = _get_common_words()
    n_rare = sum(1 for w in words if w not in common)
    rare_rate = n_rare / n_words

    # ── Hedging / formulaic phrase detection ──────────────────────────────
    formulaic_count = 0
    hedging_token_chars: set[int] = set()  # character positions flagged

    for phrase in _SORTED_PHRASES:
        start = 0
        while True:
            idx = lower.find(phrase, start)
            if idx == -1:
                break
            formulaic_count += 1
            # Mark the character range so we can estimate covered tokens
            for pos in range(idx, idx + len(phrase)):
                hedging_token_chars.add(pos)
            start = idx + len(phrase)

    # Hedging rate: fraction of word characters covered by hedging phrases
    total_word_chars = sum(len(w) for w in words)
    if total_word_chars > 0:
        # Count alpha chars in the sentence that fall within a hedging span
        alpha_positions = []
        for i, ch in enumerate(lower):
            if ch.isalpha():
                alpha_positions.append(i)
        covered = sum(1 for p in alpha_positions if p in hedging_token_chars)
        hedging_rate = covered / total_word_chars
    else:
        hedging_rate = 0.0

    return {
        "type_token_ratio": ttr,
        "rare_word_rate": rare_rate,
        "hedging_rate": hedging_rate,
        "formulaic_count": float(formulaic_count),
    }
