"""
Style feature module.

Features per sentence (passage-aware where noted)
--------------------------------------------------
sentence_length_tokens  : number of whitespace-delimited tokens
sentence_length_chars   : number of characters (excluding leading/trailing space)
length_zscore           : z-score of token count relative to passage mean/std
                          AI tends to cluster near medium length with low variance.
first_person_density    : fraction of tokens that are first-person pronouns
                          (I, me, my, mine, myself).  Personal essays should
                          use "I" naturally; AI tends to under-use or over-use it.
punctuation_variety     : unique punctuation marks / total punctuation marks.
                          Human writing uses more varied punctuation;
                          AI output is often comma- and period-heavy.

ESL note
--------
Sentence length varies legitimately across cultures and writing styles.
length_zscore is relative to the *same essay*, which mitigates inter-essay
variation.  ESL writers may have lower first_person_density due to formality
norms — another reason to treat all signals as features for a trained model
rather than hard thresholds.
"""
from __future__ import annotations

import math
import string

FEATURE_NAMES = [
    "sentence_length_tokens",
    "sentence_length_chars",
    "length_zscore",
    "first_person_density",
    "punctuation_variety",
]

FIRST_PERSON = {"i", "me", "my", "mine", "myself"}

_PUNCTUATION_SET = set(string.punctuation)


# ── Public API ─────────────────────────────────────────────────────────────────

def score_sentences(sentences: list[str]) -> list[dict]:
    """
    Compute style features for a list of sentence strings.

    All passage-level statistics (mean/std for z-score) are computed
    across the full *sentences* list so that each sentence's features
    reflect its position within the passage.

    Parameters
    ----------
    sentences : list of raw sentence strings

    Returns
    -------
    List of dicts, one per sentence, with keys matching FEATURE_NAMES.
    """
    if not sentences:
        return []

    # ── Per-sentence raw stats ────────────────────────────────────────────
    raw: list[dict] = []
    for sent in sentences:
        raw.append(_raw_stats(sent))

    # ── Passage-level statistics for z-score ─────────────────────────────
    lengths = [r["n_tokens"] for r in raw]
    mean_len = sum(lengths) / len(lengths)
    variance = sum((l - mean_len) ** 2 for l in lengths) / len(lengths)
    std_len = math.sqrt(variance)

    results = []
    for r in raw:
        z = (r["n_tokens"] - mean_len) / std_len if std_len > 1e-9 else 0.0
        results.append({
            "sentence_length_tokens": float(r["n_tokens"]),
            "sentence_length_chars": float(r["n_chars"]),
            "length_zscore": z,
            "first_person_density": r["fp_density"],
            "punctuation_variety": r["punct_variety"],
        })

    return results


# ── Internal helpers ───────────────────────────────────────────────────────────

def _raw_stats(sentence: str) -> dict:
    """Compute per-sentence raw statistics (before passage normalisation)."""
    s = sentence.strip()
    if not s:
        return {
            "n_tokens": 0,
            "n_chars": 0,
            "fp_density": 0.0,
            "punct_variety": 0.0,
        }

    tokens = s.split()
    n_tokens = len(tokens)
    n_chars = len(s)

    # First-person density
    lower_tokens = [t.strip(string.punctuation).lower() for t in tokens]
    fp_count = sum(1 for t in lower_tokens if t in FIRST_PERSON)
    fp_density = fp_count / n_tokens if n_tokens > 0 else 0.0

    # Punctuation variety
    punct_chars = [ch for ch in s if ch in _PUNCTUATION_SET]
    n_punct = len(punct_chars)
    n_unique_punct = len(set(punct_chars))
    punct_variety = n_unique_punct / n_punct if n_punct > 0 else 0.0

    return {
        "n_tokens": n_tokens,
        "n_chars": n_chars,
        "fp_density": fp_density,
        "punct_variety": punct_variety,
    }
