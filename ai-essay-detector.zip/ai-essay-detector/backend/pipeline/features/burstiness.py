"""
Burstiness feature module.

Burstiness captures the *variance* of perplexity across the passage.

Key insight
-----------
Human writing is "bursty": some sentences are complex and surprising
(high perplexity), others are simple and predictable (low perplexity).
AI-generated text tends to hover near a medium perplexity with low
variance — it is uniformly fluent.

This is closely related to the signal used in the "DetectGPT" and
"Binoculars" papers, though we compute it much more simply.

Features per sentence
---------------------
perplexity_zscore     : (sentence_perplexity - passage_mean) / passage_std
                        A z-score near 0 with low passage_std is an AI signal.
passage_perplexity_std: std-dev of all per-sentence perplexities in the passage
                        (same value for every sentence in the passage — this
                         gives the classifier a passage-level context signal)
"""
from __future__ import annotations

import math

FEATURE_NAMES = ["perplexity_zscore", "passage_perplexity_std"]


def compute(perplexities: list[float]) -> list[dict]:
    """
    Parameters
    ----------
    perplexities : per-sentence perplexity values from the perplexity module.
                   Must be the same length as the sentence list.

    Returns
    -------
    List of dicts, one per sentence, with keys from FEATURE_NAMES.
    """
    n = len(perplexities)
    if n == 0:
        return []

    # Guard against NaN / Inf coming from very short sentences
    safe = [p if math.isfinite(p) else 100.0 for p in perplexities]

    mean_p = sum(safe) / n

    # Population std (we have the full passage, not a sample)
    variance = sum((p - mean_p) ** 2 for p in safe) / n
    std_p = math.sqrt(variance)

    results = []
    for p in safe:
        z = (p - mean_p) / std_p if std_p > 1e-9 else 0.0
        results.append({
            "perplexity_zscore": z,
            "passage_perplexity_std": std_p,
        })

    return results
