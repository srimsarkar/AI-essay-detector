"""
Perplexity feature module.

Uses GPT-2 small (local, HuggingFace) to compute token log-probabilities
for each sentence.  The model is loaded once at import time and cached.

Features per sentence
---------------------
mean_log_prob   : mean log-probability of tokens (higher = more "expected" = AI signal)
perplexity      : exp(-mean_log_prob); lower = more expected = AI signal
min_token_prob  : minimum per-token probability in the sentence (AI rarely picks
                  very low-probability tokens)

Why GPT-2?
----------
GPT-2 is an open, locally runnable autoregressive LM.  Its token probabilities
are a proxy for "how predictable is this text under a strong language prior?"
AI-generated text tends to be highly predictable (low perplexity) because
generators like ChatGPT optimise for fluency.  Human text, especially personal
narrative, is less predictable.

This module does NOT decide whether text is AI-generated.  It only extracts
numerical signals that feed into the downstream classifier.
"""
from __future__ import annotations

import logging
import math
from functools import lru_cache
from typing import Optional

import torch

logger = logging.getLogger(__name__)

FEATURE_NAMES = ["mean_log_prob", "perplexity", "min_token_prob"]

# Maximum tokens fed to GPT-2 per sentence (model context window is 1024).
# Long sentences are truncated; this rarely affects short admissions essay sentences.
_MAX_TOKENS = 256

# Fallback values used when scoring fails (e.g. single-token sentence)
_FALLBACK = {"mean_log_prob": -5.0, "perplexity": math.exp(5.0), "min_token_prob": 0.01}


# ── Model singleton ────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _load_model():
    """Load GPT-2 small and its tokenizer once; cache in memory."""
    from transformers import GPT2LMHeadModel, GPT2TokenizerFast

    logger.info("perplexity: loading GPT-2 small (first call, may take a moment)…")
    tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")
    model = GPT2LMHeadModel.from_pretrained("gpt2")
    model.eval()
    # Use CPU; for a hackathon this is fast enough for sentence-level scoring
    device = torch.device("cpu")
    model.to(device)
    logger.info("perplexity: GPT-2 ready on %s", device)
    return tokenizer, model


# ── Public API ─────────────────────────────────────────────────────────────────

def score_sentences(sentences: list[str]) -> list[dict]:
    """
    Score a list of sentence strings.

    Parameters
    ----------
    sentences : list of raw sentence strings

    Returns
    -------
    List of dicts, one per sentence, with keys from FEATURE_NAMES.
    """
    tokenizer, model = _load_model()
    results = []
    for sent in sentences:
        results.append(_score_one(sent, tokenizer, model))
    return results


# ── Internal helpers ───────────────────────────────────────────────────────────

@torch.no_grad()
def _score_one(sentence: str, tokenizer, model) -> dict:
    """
    Compute perplexity features for a single sentence string.

    Strategy
    --------
    Encode the sentence, run a forward pass, collect per-token log-probs
    using the standard causal LM loss formulation (token i predicts token i+1).
    """
    if not sentence or not sentence.strip():
        return dict(_FALLBACK)

    # Encode; GPT-2 has no padding token so we just truncate
    encoding = tokenizer(
        sentence,
        return_tensors="pt",
        truncation=True,
        max_length=_MAX_TOKENS,
    )
    input_ids: torch.Tensor = encoding["input_ids"]  # (1, seq_len)

    seq_len = input_ids.shape[1]
    if seq_len < 2:
        # Can't compute conditional probabilities for a single token
        return dict(_FALLBACK)

    # Forward pass
    outputs = model(input_ids, labels=input_ids)
    # outputs.loss is the mean cross-entropy (negative mean log-prob per token)
    # We need per-token log-probs, so recompute from logits.
    logits = outputs.logits  # (1, seq_len, vocab_size)

    # Shift: logits[t] predicts token[t+1]
    shift_logits = logits[0, :-1, :]          # (seq_len-1, vocab_size)
    shift_labels = input_ids[0, 1:]           # (seq_len-1,)

    log_probs = torch.nn.functional.log_softmax(shift_logits, dim=-1)
    # Gather the log-prob of each actual token
    token_log_probs = log_probs[
        torch.arange(len(shift_labels)), shift_labels
    ]  # (seq_len-1,)

    token_log_probs_np = token_log_probs.numpy()

    mean_lp = float(token_log_probs_np.mean())
    perplexity = math.exp(-mean_lp)
    # Per-token probability (not log) for min calculation
    token_probs = torch.exp(token_log_probs).numpy()
    min_token_prob = float(token_probs.min())

    return {
        "mean_log_prob": mean_lp,
        "perplexity": perplexity,
        "min_token_prob": min_token_prob,
    }
