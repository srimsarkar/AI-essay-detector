"""
Syntactic feature module (spaCy en_core_web_sm).

Features per sentence
---------------------
pos_entropy       : Shannon entropy of the POS tag distribution.
                    AI text tends toward lower entropy (more uniform tag mix).
dep_tree_depth    : maximum depth of the dependency parse tree.
avg_dep_tree_depth: mean depth across all tokens in the sentence.
                    AI tends to use specific syntactic structures; humans vary more.

The spaCy model is loaded once via the same singleton used by the splitter.
We batch all sentences in a single nlp.pipe() call for speed.
"""
from __future__ import annotations

import math
import logging
from functools import lru_cache

logger = logging.getLogger(__name__)

FEATURE_NAMES = ["pos_entropy", "dep_tree_depth", "avg_dep_tree_depth"]


# ── spaCy singleton ────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _get_nlp():
    import spacy
    try:
        # Keep tagger + attribute_ruler active — both are needed to populate
        # token.pos_ (attribute_ruler maps fine tags → coarse POS in en_core_web_sm).
        # Only disable ner and lemmatizer (not needed for syntactic features).
        nlp = spacy.load("en_core_web_sm", disable=["ner", "lemmatizer"])
        logger.info("syntax: spaCy en_core_web_sm loaded")
        return nlp
    except OSError:
        logger.error("syntax: en_core_web_sm not found — run: python -m spacy download en_core_web_sm")
        return None


# ── Public API ─────────────────────────────────────────────────────────────────

def score_sentences(sentences: list[str]) -> list[dict]:
    """
    Compute syntactic features for a list of sentence strings.

    Parameters
    ----------
    sentences : list of raw sentence strings

    Returns
    -------
    List of dicts, one per sentence, with keys matching FEATURE_NAMES.
    """
    if not sentences:
        return []

    nlp = _get_nlp()
    if nlp is None:
        return [_fallback() for _ in sentences]

    results = []
    # Process all sentences in one batch for efficiency
    for doc in nlp.pipe(sentences, batch_size=32):
        results.append(_score_doc(doc))
    return results


# ── Internal helpers ───────────────────────────────────────────────────────────

def _fallback() -> dict:
    return {k: 0.0 for k in FEATURE_NAMES}


def _score_doc(doc) -> dict:
    """Extract syntactic features from a parsed spaCy Doc."""
    tokens = [t for t in doc if not t.is_space]
    if not tokens:
        return _fallback()

    # ── POS entropy ───────────────────────────────────────────────────────
    pos_counts: dict[str, int] = {}
    for t in tokens:
        pos_counts[t.pos_] = pos_counts.get(t.pos_, 0) + 1
    n = len(tokens)
    entropy = 0.0
    for count in pos_counts.values():
        p = count / n
        if p > 0:
            entropy -= p * math.log2(p)

    # ── Dependency tree depth ─────────────────────────────────────────────
    # Compute the depth of each token in the dependency tree.
    # Root has depth 0; its children have depth 1, etc.
    depth_map: dict[int, int] = {}

    def get_depth(token) -> int:
        if token.i in depth_map:
            return depth_map[token.i]
        if token.dep_ == "ROOT" or token.head.i == token.i:
            depth_map[token.i] = 0
            return 0
        d = get_depth(token.head) + 1
        depth_map[token.i] = d
        return d

    depths = []
    for t in tokens:
        try:
            depths.append(get_depth(t))
        except RecursionError:
            # Pathological parse tree — skip this token
            depths.append(0)

    max_depth = float(max(depths)) if depths else 0.0
    avg_depth = float(sum(depths) / len(depths)) if depths else 0.0

    return {
        "pos_entropy": entropy,
        "dep_tree_depth": max_depth,
        "avg_dep_tree_depth": avg_depth,
    }
