"""
Feature extractor orchestrator.

Calls each feature sub-module in order and assembles the results into
a single numpy array of shape (n_sentences, n_features).

Sub-modules that are not yet implemented (raise NotImplementedError)
are gracefully skipped — their columns are filled with zeros — so the
pipeline runs end-to-end from Batch 2 onward.  Each module is swapped
in as its batch is completed.

Returns
-------
features      : np.ndarray, shape (n_sentences, n_features)
feature_names : list[str]
"""
from __future__ import annotations

import logging
import numpy as np

logger = logging.getLogger(__name__)

# ── Feature module registry ───────────────────────────────────────────────────
# Each entry: (module_path, function_name, call_style)
#
# call_style:
#   "sentences"   → fn(sentence_texts: list[str]) -> list[dict]
#   "sentence"    → fn(sentence_text: str) -> dict           (called per sentence)
#   "passage"     → fn(values: list[float]) -> list[dict]    (passage-level, takes
#                    a list of a prior feature's values)
#
# "passage" modules are special: they depend on a prior module's output.
# Their config includes a "depends_on" key naming the feature they consume.

_MODULE_REGISTRY = [
    {
        "module": "pipeline.features.perplexity",
        "fn": "score_sentences",
        "style": "sentences",
        "names_attr": "FEATURE_NAMES",
    },
    {
        "module": "pipeline.features.burstiness",
        "fn": "compute",
        "style": "passage",
        "depends_on": "perplexity",   # consumes the list of perplexity values
        "names_attr": "FEATURE_NAMES",
    },
    {
        "module": "pipeline.features.vocabulary",
        "fn": "score_sentence",
        "style": "sentence",
        "names_attr": "FEATURE_NAMES",
    },
    {
        "module": "pipeline.features.style",
        "fn": "score_sentences",
        "style": "sentences",
        "names_attr": "FEATURE_NAMES",
    },
    {
        "module": "pipeline.features.syntax",
        "fn": "score_sentences",
        "style": "sentences",
        "names_attr": "FEATURE_NAMES",
    },
]


def extract_features(sentences: list[dict]) -> tuple[np.ndarray, list[str]]:
    """
    Parameters
    ----------
    sentences : list of {"text": str, "start": int, "end": int}

    Returns
    -------
    features      : np.ndarray, shape (n_sentences, n_features)
    feature_names : list[str]
    """
    if not sentences:
        return np.empty((0, 0)), []

    n = len(sentences)
    texts = [s["text"] for s in sentences]

    all_columns: list[np.ndarray] = []   # each element: (n,) array
    all_names: list[str] = []

    # Keep a dict of named per-sentence arrays for passage-level modules
    named_outputs: dict[str, list[float]] = {}

    for cfg in _MODULE_REGISTRY:
        mod_name = cfg["module"]
        fn_name = cfg["fn"]
        style = cfg["style"]
        names_attr = cfg["names_attr"]

        try:
            import importlib
            mod = importlib.import_module(mod_name)
            fn = getattr(mod, fn_name)
            feat_names: list[str] = getattr(mod, names_attr)
        except (ImportError, AttributeError) as exc:
            logger.warning("extractor: could not import %s.%s — %s", mod_name, fn_name, exc)
            feat_names = []
            fn = None

        if fn is None or not feat_names:
            continue

        n_feats = len(feat_names)

        try:
            # ── Call the module ────────────────────────────────────────────
            if style == "sentences":
                raw: list[dict] = fn(texts)

            elif style == "sentence":
                raw = [fn(t) for t in texts]

            elif style == "passage":
                dep_key = cfg.get("depends_on", "")
                dep_values = named_outputs.get(dep_key, [0.0] * n)
                raw = fn(dep_values)

            else:
                logger.error("extractor: unknown style '%s' for %s", style, mod_name)
                raw = [{k: 0.0 for k in feat_names} for _ in range(n)]

            # ── Convert to columns ─────────────────────────────────────────
            for feat_name in feat_names:
                col = np.array([float(r.get(feat_name, 0.0)) for r in raw], dtype=np.float32)
                all_columns.append(col)
                all_names.append(feat_name)

            # ── Store named outputs for downstream passage modules ─────────
            short_name = mod_name.split(".")[-1]  # e.g. "perplexity"
            if "perplexity" in feat_names:
                named_outputs["perplexity"] = [
                    float(r.get("perplexity", 0.0)) for r in raw
                ]

        except NotImplementedError:
            # Module not implemented yet — fill zeros
            logger.debug("extractor: %s.%s not yet implemented, using zeros", mod_name, fn_name)
            for feat_name in feat_names:
                all_columns.append(np.zeros(n, dtype=np.float32))
                all_names.append(feat_name)

        except Exception as exc:
            # Unexpected error — fill zeros and log
            logger.error("extractor: %s.%s raised %s, using zeros", mod_name, fn_name, exc)
            for feat_name in feat_names:
                all_columns.append(np.zeros(n, dtype=np.float32))
                all_names.append(feat_name)

    if not all_columns:
        # Nothing produced at all — return a single zero column so downstream
        # code always gets a 2D array
        return np.zeros((n, 1), dtype=np.float32), ["_placeholder"]

    features = np.column_stack(all_columns).astype(np.float32)  # (n, n_feats)
    return features, all_names
