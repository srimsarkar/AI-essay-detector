"""
Sentence splitter.

Splits an essay string into a list of sentence dicts:
    {"text": str, "start": int, "end": int}

Strategy:
  1. Try spaCy (en_core_web_sm) for high-quality sentence boundary detection.
  2. Fall back to NLTK punkt_tab tokenizer if spaCy model is not installed.
  3. Last resort: naive split on ". " / "! " / "? " patterns.

Character offsets are relative to the original essay string so the
frontend can reconstruct the highlighted view without re-searching.
"""
from __future__ import annotations

import re
import logging

logger = logging.getLogger(__name__)

# ── spaCy singleton (loaded once) ─────────────────────────────────────────────
_nlp = None


def _get_spacy():
    global _nlp
    if _nlp is not None:
        return _nlp
    try:
        import spacy
        _nlp = spacy.load("en_core_web_sm", disable=["ner", "lemmatizer", "attribute_ruler"])
        logger.info("splitter: using spaCy en_core_web_sm")
        return _nlp
    except (ImportError, OSError):
        logger.warning("splitter: spaCy model not available, will try NLTK")
        return None


# ── NLTK singleton ────────────────────────────────────────────────────────────
_nltk_tokenizer = None


def _get_nltk():
    global _nltk_tokenizer
    if _nltk_tokenizer is not None:
        return _nltk_tokenizer
    try:
        import nltk
        # Download the punkt_tab data if it is missing (silent in CI)
        try:
            nltk.data.find("tokenizers/punkt_tab")
        except LookupError:
            nltk.download("punkt_tab", quiet=True)
        from nltk.tokenize import PunktSentenceTokenizer
        # Build a default tokenizer from pre-trained English data
        _nltk_tokenizer = nltk.tokenize.sent_tokenize  # convenience function
        logger.info("splitter: using NLTK punkt tokenizer")
        return _nltk_tokenizer
    except (ImportError, LookupError):
        logger.warning("splitter: NLTK not available, using naive fallback")
        return None


# ── Public API ────────────────────────────────────────────────────────────────

def split_sentences(essay: str) -> list[dict]:
    """
    Split *essay* into sentences.

    Returns
    -------
    list of {"text": str, "start": int, "end": int}
        Offsets are character positions in the original *essay* string.
        The list preserves the original order.
    """
    essay = essay.strip()
    if not essay:
        return []

    # --- attempt spaCy ---
    nlp = _get_spacy()
    if nlp is not None:
        return _split_with_spacy(essay, nlp)

    # --- attempt NLTK ---
    sent_tokenize = _get_nltk()
    if sent_tokenize is not None:
        return _split_with_nltk(essay, sent_tokenize)

    # --- naive fallback ---
    return _split_naive(essay)


# ── Backend implementations ───────────────────────────────────────────────────

def _split_with_spacy(essay: str, nlp) -> list[dict]:
    doc = nlp(essay)
    results = []
    for sent in doc.sents:
        text = sent.text.strip()
        if not text:
            continue
        # sent.start_char / sent.end_char are relative to the doc (= essay)
        # but we want offsets in the *original* essay string.
        # Locate the stripped text within the original span.
        raw_start = sent.start_char
        raw_end = sent.end_char
        # Adjust for leading/trailing whitespace that .strip() removed
        stripped_offset = len(sent.text) - len(sent.text.lstrip())
        start = raw_start + stripped_offset
        end = start + len(text)
        results.append({"text": text, "start": start, "end": end})
    return results


def _split_with_nltk(essay: str, sent_tokenize) -> list[dict]:
    spans = sent_tokenize(essay)
    results = []
    cursor = 0
    for span in spans:
        text = span.strip()
        if not text:
            continue
        idx = essay.find(text, cursor)
        if idx == -1:
            # Shouldn't happen, but fall back to cursor position
            idx = cursor
        end = idx + len(text)
        results.append({"text": text, "start": idx, "end": end})
        cursor = end
    return results


def _split_naive(essay: str) -> list[dict]:
    """
    Very simple regex-based fallback.
    Splits on sentence-ending punctuation followed by whitespace or end-of-string.
    """
    pattern = re.compile(r'(?<=[.!?])\s+')
    raw_sentences = pattern.split(essay)
    results = []
    cursor = 0
    for raw in raw_sentences:
        text = raw.strip()
        if not text:
            continue
        idx = essay.find(text, cursor)
        if idx == -1:
            idx = cursor
        end = idx + len(text)
        results.append({"text": text, "start": idx, "end": end})
        cursor = end
    return results
