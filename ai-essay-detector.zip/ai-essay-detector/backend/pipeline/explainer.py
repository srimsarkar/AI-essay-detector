"""
Evidence generator.

For each sentence converts feature values + SHAP attributions into a list
of human-readable evidence dicts:
    {"signal": str, "value": float, "explanation": str}

Strategy
--------
1. Compute SHAP values using shap.Explainer on the base estimator.
   We use the linear approximation path through the calibrated model.
2. For each sentence, take the top-N features by |SHAP value|.
3. Map each feature to a template explanation that describes what the
   signal means and whether it points toward AI or human.

Why not just use SHAP directly for the final decision?
------------------------------------------------------
SHAP is used *only* to attribute which features drove the classifier's
prediction.  The classifier itself made the decision based on learned
weights — SHAP just helps us explain it post-hoc.
"""
from __future__ import annotations

import logging
import numpy as np

logger = logging.getLogger(__name__)

# Number of top features to surface per sentence
_TOP_N = 4

# ── Human-readable templates per feature ─────────────────────────────────────
# Each template is a dict with:
#   fmt_ai    : explanation shown when the feature pushes toward AI
#   fmt_human : explanation shown when it pushes toward human
#   value_fmt : how to format the raw value (e.g. ".1f" for perplexity)
#   unit      : optional unit string

_TEMPLATES: dict[str, dict] = {
    "perplexity": {
        "fmt_ai":    "Low perplexity ({value:.1f}) — GPT-2 found this sentence highly predictable, "
                     "which is characteristic of AI-generated text.",
        "fmt_human": "High perplexity ({value:.1f}) — GPT-2 found this sentence relatively "
                     "unpredictable, more consistent with human writing.",
    },
    "mean_log_prob": {
        "fmt_ai":    "High mean token log-probability ({value:.3f}) — each token was likely "
                     "given the preceding context, an AI fluency signal.",
        "fmt_human": "Low mean token log-probability ({value:.3f}) — tokens were less "
                     "predictable, suggesting natural human variation.",
    },
    "min_token_prob": {
        "fmt_ai":    "High minimum token probability ({value:.4f}) — even the least "
                     "likely word choice was common, suggesting AI output.",
        "fmt_human": "Low minimum token probability ({value:.4f}) — at least one word "
                     "was an unusual choice, consistent with human specificity.",
    },
    "perplexity_zscore": {
        "fmt_ai":    "Perplexity z-score near zero ({value:.2f}) — this sentence's complexity "
                     "is close to the passage average, indicating low burstiness.",
        "fmt_human": "Perplexity z-score of {value:.2f} — this sentence stands out in "
                     "complexity relative to the surrounding passage.",
    },
    "passage_perplexity_std": {
        "fmt_ai":    "Low passage perplexity variance (std={value:.1f}) — sentence complexity "
                     "is unusually uniform across the passage, an AI burstiness signal.",
        "fmt_human": "High passage perplexity variance (std={value:.1f}) — complexity "
                     "varies significantly across the passage, consistent with human writing.",
    },
    "type_token_ratio": {
        "fmt_ai":    "Low type-token ratio ({value:.2f}) — vocabulary is relatively repetitive, "
                     "which can indicate formulaic AI phrasing.",
        "fmt_human": "High type-token ratio ({value:.2f}) — vocabulary is varied and "
                     "non-repetitive, consistent with natural human expression.",
    },
    "rare_word_rate": {
        "fmt_ai":    "Low rare-word rate ({value:.2f}) — mostly common vocabulary, "
                     "which can indicate AI's preference for safe, high-probability words.",
        "fmt_human": "High rare-word rate ({value:.2f}) — contains relatively uncommon "
                     "words, which can indicate human specificity or expertise.",
    },
    "hedging_rate": {
        "fmt_ai":    "Elevated hedging language rate ({value:.2f}) — contains phrasing "
                     "characteristic of AI-generated text (e.g. 'furthermore', 'it is "
                     "important to note').",
        "fmt_human": "Low hedging language rate ({value:.2f}) — minimal use of AI-typical "
                     "transitional or hedging phrases.",
    },
    "formulaic_count": {
        "fmt_ai":    "{value:.0f} formulaic AI phrase(s) detected — e.g. 'in conclusion', "
                     "'multifaceted', 'delve into', or similar patterns common in LLM output.",
        "fmt_human": "No formulaic AI phrases detected — language appears natural.",
    },
    "sentence_length_tokens": {
        "fmt_ai":    "Sentence length ({value:.0f} tokens) is in the range typical of "
                     "AI-generated text for this passage.",
        "fmt_human": "Sentence length ({value:.0f} tokens) is atypical for this passage, "
                     "suggesting natural human variation.",
    },
    "length_zscore": {
        "fmt_ai":    "Length z-score of {value:.2f} — sentence length is close to the passage "
                     "average, contributing to low length variance (AI signal).",
        "fmt_human": "Length z-score of {value:.2f} — sentence length stands out within the "
                     "passage, which is natural for human writing.",
    },
    "first_person_density": {
        "fmt_ai":    "Low first-person pronoun density ({value:.2f}) — limited use of 'I'/'me'/'my', "
                     "which can indicate AI avoiding personal voice.",
        "fmt_human": "First-person density of {value:.2f} — natural use of personal pronouns "
                     "consistent with authentic narrative.",
    },
    "punctuation_variety": {
        "fmt_ai":    "Low punctuation variety ({value:.2f}) — repetitive punctuation patterns "
                     "characteristic of AI output.",
        "fmt_human": "High punctuation variety ({value:.2f}) — varied punctuation consistent "
                     "with natural human expression.",
    },
    "pos_entropy": {
        "fmt_ai":    "Low POS tag entropy ({value:.2f} bits) — part-of-speech distribution is "
                     "unusually uniform, an AI syntactic signal.",
        "fmt_human": "POS tag entropy of {value:.2f} bits — diverse part-of-speech usage "
                     "consistent with natural human writing.",
    },
    "dep_tree_depth": {
        "fmt_ai":    "Dependency tree depth of {value:.0f} — syntactic complexity matches "
                     "patterns found in AI-generated sentences.",
        "fmt_human": "Dependency tree depth of {value:.0f} — syntactic structure is "
                     "consistent with natural human sentence construction.",
    },
    "avg_dep_tree_depth": {
        "fmt_ai":    "Average dependency depth of {value:.2f} — sentence structure matches "
                     "AI-characteristic syntactic patterns.",
        "fmt_human": "Average dependency depth of {value:.2f} — syntactic structure "
                     "is consistent with natural human writing.",
    },
}

_DEFAULT_TEMPLATE = {
    "fmt_ai":    "Signal '{name}' = {value:.3f} pushes toward AI.",
    "fmt_human": "Signal '{name}' = {value:.3f} pushes toward human.",
}


# ── Public API ─────────────────────────────────────────────────────────────────

def explain(
    features: np.ndarray,
    feature_names: list[str],
    probabilities: np.ndarray,
) -> list[list[dict]]:
    """
    Generate per-sentence evidence lists.

    Parameters
    ----------
    features      : (n_sentences, n_features)
    feature_names : list[str]
    probabilities : (n_sentences,)

    Returns
    -------
    List of per-sentence evidence lists.
    Each item: {"signal": str, "value": float, "explanation": str}
    """
    if features.shape[0] == 0:
        return []

    shap_values = _compute_shap(features, feature_names)

    results = []
    for i in range(features.shape[0]):
        evidence = _build_evidence(
            feat_row=features[i],
            shap_row=shap_values[i],
            feature_names=feature_names,
            ai_prob=float(probabilities[i]),
        )
        results.append(evidence)
    return results


# ── SHAP computation ──────────────────────────────────────────────────────────

def _compute_shap(features: np.ndarray, feature_names: list[str]) -> np.ndarray:
    """
    Compute SHAP values for the feature matrix.

    Returns an (n_sentences, n_features) array of SHAP values.
    Falls back to normalised feature deltas if SHAP fails.
    """
    try:
        import shap
        from pipeline.classifier import _load_bundle

        bundle = _load_bundle()
        model  = bundle["model"]
        scaler = bundle["scaler"]

        X_scaled = scaler.transform(features)

        # Use Permutation explainer — works with any sklearn model
        # Use a small background sample (mean of training features via scaler mean)
        background = np.zeros((1, features.shape[1]), dtype=np.float32)
        background_scaled = scaler.transform(background)

        explainer = shap.explainers.Permutation(
            model.predict_proba,
            background_scaled,
            max_evals=2 * features.shape[1] + 1,
        )
        shap_out = explainer(X_scaled)
        # shap_out.values shape: (n, n_features, n_classes)
        # We want class-1 (AI) SHAP values
        sv = shap_out.values
        if sv.ndim == 3:
            sv = sv[:, :, 1]   # (n, n_features) for AI class
        return sv.astype(np.float32)

    except Exception as exc:
        logger.warning("SHAP computation failed (%s), using feature-delta fallback", exc)
        return _fallback_attributions(features, feature_names)


def _fallback_attributions(features: np.ndarray, feature_names: list[str]) -> np.ndarray:
    """
    Simple fallback: return z-score-normalised feature values as attribution proxies.
    Not as accurate as SHAP but never fails.
    """
    mean = features.mean(axis=0, keepdims=True)
    std  = features.std(axis=0, keepdims=True)
    std  = np.where(std < 1e-9, 1.0, std)
    return ((features - mean) / std).astype(np.float32)


# ── Evidence builder ──────────────────────────────────────────────────────────

def _build_evidence(
    feat_row: np.ndarray,
    shap_row: np.ndarray,
    feature_names: list[str],
    ai_prob: float,
) -> list[dict]:
    """
    Build evidence items for a single sentence.

    Picks the top-N features by |SHAP value| and formats them into
    human-readable explanation strings.
    """
    n = len(feature_names)
    abs_shap = np.abs(shap_row[:n])
    top_idx = np.argsort(abs_shap)[::-1][:_TOP_N]

    evidence = []
    for idx in top_idx:
        if idx >= len(feature_names):
            continue
        name  = feature_names[idx]
        value = float(feat_row[idx])
        shap_val = float(shap_row[idx])

        # Positive SHAP → pushes toward AI; negative → toward human
        toward_ai = shap_val > 0
        tmpl = _TEMPLATES.get(name, _DEFAULT_TEMPLATE)

        try:
            if toward_ai:
                explanation = tmpl["fmt_ai"].format(value=value, name=name)
            else:
                explanation = tmpl["fmt_human"].format(value=value, name=name)
        except (KeyError, ValueError):
            explanation = f"{name} = {value:.4f}"

        evidence.append({
            "signal": name,
            "value": round(value, 4),
            "explanation": explanation,
            "shap": round(shap_val, 4),
        })

    return evidence
