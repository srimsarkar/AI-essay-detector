"""
Classifier wrapper.

Loads the trained scikit-learn model bundle from backend/models/classifier.pkl
and exposes classify() which returns per-sentence AI probability scores.

The bundle contains:
    model         : CalibratedClassifierCV wrapping HistGradientBoostingClassifier
    scaler        : StandardScaler fitted on training data
    feature_names : list[str] — must match the extractor's output order
"""
from __future__ import annotations

import os
import pickle
import logging
from functools import lru_cache

import numpy as np

logger = logging.getLogger(__name__)

_HERE = os.path.dirname(__file__)
_MODEL_PATH = os.path.join(_HERE, "..", "models", "classifier.pkl")


# ── Model singleton ────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _load_bundle() -> dict:
    path = os.path.abspath(_MODEL_PATH)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Classifier model not found at {path}. "
            "Run `python -m training.train` from the backend/ directory first."
        )
    with open(path, "rb") as f:
        bundle = pickle.load(f)
    logger.info("classifier: loaded model from %s", path)
    return bundle


# ── Public API ─────────────────────────────────────────────────────────────────

def classify(features: np.ndarray) -> np.ndarray:
    """
    Predict AI probability for each sentence.

    Parameters
    ----------
    features : np.ndarray, shape (n_sentences, n_features)
        Raw feature matrix from extractor.extract_features().

    Returns
    -------
    probabilities : np.ndarray, shape (n_sentences,)
        P(AI) for each sentence, range [0, 1].
    """
    if features.shape[0] == 0:
        return np.array([], dtype=np.float32)

    bundle = _load_bundle()
    model  = bundle["model"]
    scaler = bundle["scaler"]

    # Scale features — the scaler was fit on the training set
    X_scaled = scaler.transform(features)

    # predict_proba returns [P(human), P(AI)]; we want P(AI)
    probs = model.predict_proba(X_scaled)[:, 1]
    return probs.astype(np.float32)


def get_feature_names() -> list[str]:
    """Return the feature names the model was trained on."""
    return list(_load_bundle()["feature_names"])
