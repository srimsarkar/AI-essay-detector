"""
API routes for the AI Essay Detector.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter()


# ── Request / response models ─────────────────────────────────────────────────

class EssayRequest(BaseModel):
    essay: str = Field(..., min_length=50, description="The college admissions essay text to analyze.")


class EvidenceItem(BaseModel):
    signal: str
    value: float
    explanation: str
    shap: float = 0.0


class SentenceResult(BaseModel):
    sentence: str
    start_char: int
    end_char: int
    ai_probability: float          # 0.0 – 1.0
    label: str                     # "human" | "uncertain" | "ai"
    evidence: list[EvidenceItem]


class AnalysisResponse(BaseModel):
    essay: str
    sentences: list[SentenceResult]
    overall_ai_probability: float
    overall_label: str
    model_version: str = "1.0"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _label(prob: float) -> str:
    if prob >= 0.65:
        return "ai"
    if prob >= 0.35:
        return "uncertain"
    return "human"


# ── Route ─────────────────────────────────────────────────────────────────────

@router.post("/analyze", response_model=AnalysisResponse)
def analyze_essay(body: EssayRequest):
    """
    Analyze an admissions essay for AI-generated content.

    Pipeline:
        1. Split essay into sentences (spaCy / NLTK / naive fallback)
        2. Extract 17 linguistic features per sentence
           (perplexity, burstiness, vocabulary, style, syntax)
        3. Classify with calibrated HistGradientBoosting model
        4. Generate SHAP-based evidence per sentence
        5. Return structured JSON response
    """
    from pipeline.splitter import split_sentences
    from pipeline.extractor import extract_features
    from pipeline.classifier import classify, get_feature_names
    from pipeline.explainer import explain

    essay = body.essay.strip()

    # ── 1. Sentence splitting ─────────────────────────────────────────────
    try:
        sentence_dicts = split_sentences(essay)
    except Exception as exc:
        logger.error("Sentence splitting failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Sentence splitting failed: {exc}")

    if not sentence_dicts:
        raise HTTPException(status_code=422, detail="Could not extract any sentences from the essay.")

    # ── 2. Feature extraction ─────────────────────────────────────────────
    try:
        features, feat_names = extract_features(sentence_dicts)
    except Exception as exc:
        logger.error("Feature extraction failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Feature extraction failed: {exc}")

    # ── 3. Classification ─────────────────────────────────────────────────
    try:
        probs = classify(features)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Classifier model not found. Run `python -m training.train` first."
        )
    except Exception as exc:
        logger.error("Classification failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Classification failed: {exc}")

    # ── 4. Evidence generation ────────────────────────────────────────────
    try:
        evidence_lists = explain(features, feat_names, probs)
    except Exception as exc:
        logger.warning("Evidence generation failed (%s), returning empty evidence", exc)
        evidence_lists = [[] for _ in sentence_dicts]

    # ── 5. Assemble response ──────────────────────────────────────────────
    sentence_results = []
    for i, sent in enumerate(sentence_dicts):
        prob  = float(probs[i])
        label = _label(prob)
        raw_evidence = evidence_lists[i] if i < len(evidence_lists) else []
        evidence_items = [
            EvidenceItem(
                signal=e.get("signal", ""),
                value=float(e.get("value", 0.0)),
                explanation=e.get("explanation", ""),
                shap=float(e.get("shap", 0.0)),
            )
            for e in raw_evidence
        ]
        sentence_results.append(
            SentenceResult(
                sentence=sent["text"],
                start_char=sent["start"],
                end_char=sent["end"],
                ai_probability=round(prob, 4),
                label=label,
                evidence=evidence_items,
            )
        )

    # Overall: weighted mean probability (longer sentences weighted more)
    if sentence_results:
        lengths = [max(1, len(s.sentence)) for s in sentence_results]
        total_len = sum(lengths)
        overall_prob = sum(
            s.ai_probability * l for s, l in zip(sentence_results, lengths)
        ) / total_len
    else:
        overall_prob = 0.0

    return AnalysisResponse(
        essay=essay,
        sentences=sentence_results,
        overall_ai_probability=round(overall_prob, 4),
        overall_label=_label(overall_prob),
    )
