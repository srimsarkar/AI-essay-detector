"""
Unit tests for feature extraction modules.

Tests for completed batches are live (no xfail).
Tests for future batches remain xfail until implemented.
"""
import math
import pytest
import numpy as np


# ── Batch 2: Splitter ─────────────────────────────────────────────────────────

class TestSplitter:
    def test_basic_two_sentences(self):
        from pipeline.splitter import split_sentences
        result = split_sentences("This is sentence one. This is sentence two.")
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["text"] == "This is sentence one."
        assert result[1]["text"] == "This is sentence two."

    def test_offsets_are_correct(self):
        from pipeline.splitter import split_sentences
        essay = "Hello world. Goodbye world."
        result = split_sentences(essay)
        for sent in result:
            # The slice must reproduce the sentence text
            assert essay[sent["start"]:sent["end"]] == sent["text"]

    def test_empty_string_returns_empty_list(self):
        from pipeline.splitter import split_sentences
        assert split_sentences("") == []
        assert split_sentences("   ") == []

    def test_single_sentence_no_period(self):
        from pipeline.splitter import split_sentences
        result = split_sentences("I love computer science")
        assert len(result) >= 1
        assert result[0]["text"] == "I love computer science"

    def test_exclamation_and_question(self):
        from pipeline.splitter import split_sentences
        result = split_sentences("Really? Yes! Absolutely.")
        assert len(result) == 3

    def test_paragraph_of_text(self):
        from pipeline.splitter import split_sentences
        essay = (
            "Growing up in a small town, I learned the value of community. "
            "Every summer, my family volunteered at the local food bank. "
            "These experiences shaped who I am today."
        )
        result = split_sentences(essay)
        assert len(result) == 3
        # All offsets must be non-negative and increasing
        for i in range(len(result) - 1):
            assert result[i]["end"] <= result[i + 1]["start"]

    def test_result_keys(self):
        from pipeline.splitter import split_sentences
        result = split_sentences("One sentence.")
        assert set(result[0].keys()) == {"text", "start", "end"}


# ── Batch 2: Extractor shell ──────────────────────────────────────────────────

class TestExtractorShell:
    """
    The extractor shell should return a correctly shaped zero matrix
    (because sub-modules raise NotImplementedError) without crashing.
    """

    def test_returns_ndarray_and_names(self):
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features

        sentences = split_sentences(
            "Growing up in a small town, I learned the value of community. "
            "Every summer, my family volunteered at the local food bank."
        )
        features, names = extract_features(sentences)
        assert isinstance(features, np.ndarray)
        assert isinstance(names, list)

    def test_shape_matches_sentence_count(self):
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features

        essay = "First sentence. Second sentence. Third sentence."
        sentences = split_sentences(essay)
        features, names = extract_features(sentences)
        assert features.shape[0] == len(sentences)
        assert features.shape[1] == len(names)
        assert features.shape[1] > 0

    def test_empty_input(self):
        from pipeline.extractor import extract_features
        features, names = extract_features([])
        assert features.shape[0] == 0

    def test_feature_names_are_strings(self):
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features

        sentences = split_sentences("One sentence only.")
        _, names = extract_features(sentences)
        assert all(isinstance(n, str) for n in names)

    def test_unimplemented_modules_fill_zeros(self):
        """
        Modules that raise NotImplementedError contribute zero columns.
        Implemented modules (perplexity, burstiness) contribute real values.
        The matrix must be finite throughout.
        """
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features

        sentences = split_sentences("One sentence only.")
        features, names = extract_features(sentences)
        # All values must be finite (no NaN / Inf leaking through)
        assert np.all(np.isfinite(features))
        # The perplexity column should not be zero for a real sentence
        if "perplexity" in names:
            idx = names.index("perplexity")
            assert features[0, idx] > 0


# ── Batch 3: Perplexity & Burstiness ─────────────────────────────────────────

class TestPerplexity:
    def test_returns_expected_keys(self):
        from pipeline.features.perplexity import score_sentences, FEATURE_NAMES
        result = score_sentences(["The quick brown fox jumps over the lazy dog."])
        assert len(result) == 1
        for key in FEATURE_NAMES:
            assert key in result[0]

    def test_values_are_finite_floats(self):
        from pipeline.features.perplexity import score_sentences
        result = score_sentences(["Growing up, I learned that hard work matters."])
        r = result[0]
        assert math.isfinite(r["mean_log_prob"])
        assert math.isfinite(r["perplexity"])
        assert math.isfinite(r["min_token_prob"])

    def test_perplexity_is_positive(self):
        from pipeline.features.perplexity import score_sentences
        result = score_sentences(["In conclusion, it is important to note the multifaceted nature of this issue."])
        assert result[0]["perplexity"] > 0

    def test_mean_log_prob_is_negative(self):
        """Log-probs are always <= 0 for a valid probability distribution."""
        from pipeline.features.perplexity import score_sentences
        result = score_sentences(["She walked to the store and bought milk."])
        assert result[0]["mean_log_prob"] <= 0

    def test_min_token_prob_in_range(self):
        from pipeline.features.perplexity import score_sentences
        result = score_sentences(["I grew up in a small town surrounded by mountains."])
        assert 0.0 <= result[0]["min_token_prob"] <= 1.0

    def test_multiple_sentences(self):
        from pipeline.features.perplexity import score_sentences
        sents = [
            "This is a simple sentence.",
            "Furthermore, it is imperative to consider the multifaceted implications.",
        ]
        result = score_sentences(sents)
        assert len(result) == 2

    def test_empty_sentence_returns_fallback(self):
        from pipeline.features.perplexity import score_sentences, FEATURE_NAMES
        result = score_sentences([""])
        for key in FEATURE_NAMES:
            assert key in result[0]

    def test_ai_text_lower_perplexity_than_random(self):
        """
        A smooth, fluent AI-style sentence should have lower perplexity
        than a sentence with unusual word choices.
        """
        from pipeline.features.perplexity import score_sentences
        fluent = ["In conclusion, this experience has shaped my perspective significantly."]
        unusual = ["Blorp zxqy the wonkiest frumious bandersnatch ever galumphed."]
        r_fluent = score_sentences(fluent)[0]["perplexity"]
        r_unusual = score_sentences(unusual)[0]["perplexity"]
        assert r_fluent < r_unusual


class TestBurstiness:
    def test_returns_expected_keys(self):
        from pipeline.features.burstiness import compute, FEATURE_NAMES
        result = compute([50.0, 30.0, 80.0, 20.0])
        assert len(result) == 4
        for r in result:
            for key in FEATURE_NAMES:
                assert key in r

    def test_uniform_perplexity_gives_zero_std(self):
        from pipeline.features.burstiness import compute
        result = compute([40.0, 40.0, 40.0])
        for r in result:
            assert r["passage_perplexity_std"] == pytest.approx(0.0, abs=1e-6)
            assert r["perplexity_zscore"] == pytest.approx(0.0, abs=1e-6)

    def test_varied_perplexity_gives_nonzero_std(self):
        from pipeline.features.burstiness import compute
        result = compute([10.0, 50.0, 100.0])
        assert result[0]["passage_perplexity_std"] > 0

    def test_zscore_signs_are_correct(self):
        from pipeline.features.burstiness import compute
        # [10, 50, 90] → mean=50; first z < 0, last z > 0
        result = compute([10.0, 50.0, 90.0])
        assert result[0]["perplexity_zscore"] < 0   # below mean
        assert result[2]["perplexity_zscore"] > 0   # above mean

    def test_single_sentence_no_crash(self):
        from pipeline.features.burstiness import compute
        result = compute([42.0])
        assert len(result) == 1
        assert result[0]["passage_perplexity_std"] == pytest.approx(0.0, abs=1e-6)

    def test_empty_input(self):
        from pipeline.features.burstiness import compute
        assert compute([]) == []


# ── Batch 4: Vocabulary ───────────────────────────────────────────────────────

class TestVocabulary:
    def test_returns_expected_keys(self):
        from pipeline.features.vocabulary import score_sentence, FEATURE_NAMES
        result = score_sentence("The student worked hard every single day.")
        for key in FEATURE_NAMES:
            assert key in result

    def test_hedging_detected(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence(
            "Furthermore, it is important to note that hard work pays off."
        )
        assert result["hedging_rate"] > 0
        assert result["formulaic_count"] >= 2  # "furthermore" + "it is important to note"

    def test_no_hedging_in_personal_sentence(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("My grandmother taught me to make dumplings every Sunday.")
        assert result["formulaic_count"] == 0

    def test_ttr_range(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("The cat sat on the mat by the cat.")
        assert 0.0 < result["type_token_ratio"] <= 1.0

    def test_ttr_all_unique(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("Running jumping swimming dancing singing.")
        assert result["type_token_ratio"] == pytest.approx(1.0)

    def test_ttr_all_same(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("the the the the the")
        assert result["type_token_ratio"] == pytest.approx(1 / 5)

    def test_rare_word_rate_range(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("I went to the store to buy bread and milk.")
        assert 0.0 <= result["rare_word_rate"] <= 1.0

    def test_empty_sentence(self):
        from pipeline.features.vocabulary import score_sentence, FEATURE_NAMES
        result = score_sentence("")
        for key in FEATURE_NAMES:
            assert key in result

    def test_in_conclusion_detected(self):
        from pipeline.features.vocabulary import score_sentence
        result = score_sentence("In conclusion, my experience has been invaluable.")
        assert result["formulaic_count"] >= 1

    def test_ai_sentence_higher_hedging_than_personal(self):
        from pipeline.features.vocabulary import score_sentence
        ai = score_sentence(
            "In conclusion, it is important to note that this experience "
            "has been invaluable and multifaceted."
        )
        human = score_sentence(
            "That summer I fixed engines with my uncle in his garage."
        )
        assert ai["formulaic_count"] > human["formulaic_count"]


# ── Batch 4: Style ────────────────────────────────────────────────────────────

class TestStyle:
    def test_returns_expected_keys(self):
        from pipeline.features.style import score_sentences, FEATURE_NAMES
        results = score_sentences(["I worked hard every single day."])
        assert len(results) == 1
        for key in FEATURE_NAMES:
            assert key in results[0]

    def test_token_count_correct(self):
        from pipeline.features.style import score_sentences
        results = score_sentences(["One two three four five."])
        assert results[0]["sentence_length_tokens"] == 5

    def test_char_count_correct(self):
        from pipeline.features.style import score_sentences
        s = "Hello world."
        results = score_sentences([s])
        assert results[0]["sentence_length_chars"] == len(s)

    def test_first_person_detected(self):
        from pipeline.features.style import score_sentences
        results = score_sentences(["I told my friend that I was proud of my work."])
        assert results[0]["first_person_density"] > 0

    def test_no_first_person(self):
        from pipeline.features.style import score_sentences
        results = score_sentences(["The scientist conducted an experiment."])
        assert results[0]["first_person_density"] == pytest.approx(0.0)

    def test_length_zscore_uniform(self):
        """When all sentences are the same length, z-scores should all be 0."""
        from pipeline.features.style import score_sentences
        sents = ["One two three.", "Four five six.", "Seven eight nine."]
        results = score_sentences(sents)
        for r in results:
            assert r["length_zscore"] == pytest.approx(0.0, abs=1e-6)

    def test_length_zscore_varies(self):
        from pipeline.features.style import score_sentences
        sents = [
            "Short.",
            "This is a much longer sentence with many more words in it.",
        ]
        results = score_sentences(sents)
        assert results[0]["length_zscore"] < 0  # shorter than mean
        assert results[1]["length_zscore"] > 0  # longer than mean

    def test_punctuation_variety_range(self):
        from pipeline.features.style import score_sentences
        results = score_sentences(["Wait — really? Yes, absolutely!"])
        assert 0.0 < results[0]["punctuation_variety"] <= 1.0

    def test_empty_list(self):
        from pipeline.features.style import score_sentences
        assert score_sentences([]) == []

    def test_multiple_sentences_shape(self):
        from pipeline.features.style import score_sentences, FEATURE_NAMES
        sents = ["First.", "Second sentence here.", "Third and final sentence."]
        results = score_sentences(sents)
        assert len(results) == 3
        for r in results:
            assert set(r.keys()) == set(FEATURE_NAMES)


# ── Batch 5: Syntax ───────────────────────────────────────────────────────────

class TestSyntax:
    def test_returns_expected_keys(self):
        from pipeline.features.syntax import score_sentences, FEATURE_NAMES
        results = score_sentences(["She walked quickly to the store."])
        assert len(results) == 1
        for key in FEATURE_NAMES:
            assert key in results[0]

    def test_pos_entropy_positive(self):
        from pipeline.features.syntax import score_sentences
        results = score_sentences(["The quick brown fox jumps over the lazy dog."])
        assert results[0]["pos_entropy"] > 0

    def test_dep_tree_depth_positive(self):
        from pipeline.features.syntax import score_sentences
        results = score_sentences(["The scientist who discovered the cure won the prize."])
        assert results[0]["dep_tree_depth"] >= 1

    def test_avg_depth_lte_max_depth(self):
        from pipeline.features.syntax import score_sentences
        results = score_sentences(["Growing up in a small town shaped who I am."])
        r = results[0]
        assert r["avg_dep_tree_depth"] <= r["dep_tree_depth"] + 1e-9

    def test_simple_sentence_lower_depth_than_complex(self):
        from pipeline.features.syntax import score_sentences
        simple = score_sentences(["The cat sat."])[0]["dep_tree_depth"]
        complex_ = score_sentences([
            "The incredibly talented student, who had spent years studying "
            "under world-renowned professors, finally graduated."
        ])[0]["dep_tree_depth"]
        assert complex_ >= simple

    def test_multiple_sentences(self):
        from pipeline.features.syntax import score_sentences
        sents = ["I ran.", "She studied all night.", "They celebrated together."]
        results = score_sentences(sents)
        assert len(results) == 3

    def test_empty_list(self):
        from pipeline.features.syntax import score_sentences
        assert score_sentences([]) == []
