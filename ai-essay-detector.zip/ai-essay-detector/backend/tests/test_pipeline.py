"""
Integration tests for the full analysis pipeline and API endpoint.
"""
import pytest
import pytest


class TestFullPipeline:
    """End-to-end: essay in → probabilities out."""

    def test_returns_probabilities_for_each_sentence(self):
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features
        from pipeline.classifier import classify

        essay = (
            "Growing up in a small town, I learned the value of community. "
            "Every summer, my family volunteered at the local food bank. "
            "These experiences shaped who I am today."
        )
        sentences = split_sentences(essay)
        features, _ = extract_features(sentences)
        probs = classify(features)
        assert probs.shape[0] == len(sentences)
        assert all(0.0 <= float(p) <= 1.0 for p in probs)

    def test_probabilities_differ_between_human_and_ai(self):
        """AI-style sentence should score higher than an authentic personal one."""
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features
        from pipeline.classifier import classify

        human_essay = "I once burned three batches of bread before finally getting the crust right."
        ai_essay = (
            "In conclusion, it is important to note that this multifaceted experience "
            "has been truly invaluable in shaping my academic journey."
        )
        for essay in [human_essay, ai_essay]:
            sents = split_sentences(essay)
            feats, _ = extract_features(sents)
            probs = classify(feats)
            assert probs.shape[0] == len(sents)

    def test_explainer_returns_evidence_per_sentence(self):
        from pipeline.splitter import split_sentences
        from pipeline.extractor import extract_features
        from pipeline.classifier import classify
        from pipeline.explainer import explain

        essay = (
            "Furthermore, it is important to note that my journey has been multifaceted. "
            "I burned the bread three times before I got it right."
        )
        sents = split_sentences(essay)
        feats, feat_names = extract_features(sents)
        probs = classify(feats)
        evidence = explain(feats, feat_names, probs)

        assert len(evidence) == len(sents)
        for ev_list in evidence:
            assert isinstance(ev_list, list)
            for item in ev_list:
                assert "signal" in item
                assert "explanation" in item
                assert "value" in item


class TestAPIAnalyzeEndpoint:
    """Integration test for the /api/analyze route."""

    def test_returns_200_with_sentence_results(self):
        from fastapi.testclient import TestClient
        from main import app

        client = TestClient(app)
        response = client.post(
            "/api/analyze",
            json={
                "essay": (
                    "Growing up in a small town, I learned the value of community. "
                    "Every summer, my family volunteered at the local food bank. "
                    "These experiences shaped who I am today."
                )
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "sentences" in data
        assert len(data["sentences"]) >= 1
        s = data["sentences"][0]
        assert "ai_probability" in s
        assert "label" in s
        assert "evidence" in s
        assert 0.0 <= s["ai_probability"] <= 1.0
        assert s["label"] in ("human", "uncertain", "ai")

    def test_overall_probability_present(self):
        from fastapi.testclient import TestClient
        from main import app

        client = TestClient(app)
        response = client.post(
            "/api/analyze",
            json={"essay": "I built my first website at twelve using a tutorial I found in a library book from 2003."}
        )
        assert response.status_code == 200
        data = response.json()
        assert "overall_ai_probability" in data
        assert "overall_label" in data

    def test_too_short_essay_rejected(self):
        from fastapi.testclient import TestClient
        from main import app

        client = TestClient(app)
        response = client.post("/api/analyze", json={"essay": "Too short."})
        assert response.status_code == 422

    def test_ai_essay_scores_higher_than_human(self):
        from fastapi.testclient import TestClient
        from main import app

        client = TestClient(app)

        human = client.post("/api/analyze", json={
            "essay": (
                "I once burned three batches of bread before getting it right. "
                "My grandmother watched without saying a word. "
                "She handed me a dish towel when I finally got the crust."
            )
        }).json()

        ai = client.post("/api/analyze", json={
            "essay": (
                "In conclusion, it is important to note that this transformative experience "
                "has been truly invaluable. Furthermore, my multifaceted background has "
                "equipped me with the tools to navigate the complexities of this endeavor."
            )
        }).json()

        assert ai["overall_ai_probability"] >= human["overall_ai_probability"]
