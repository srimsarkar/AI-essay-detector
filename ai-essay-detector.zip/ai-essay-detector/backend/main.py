"""
AI Essay Detector — FastAPI entry point.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from api.routes import router

app = FastAPI(
    title="AI Essay Detector",
    description="Detects AI-generated passages in college admissions essays using measurable linguistic signals.",
    version="0.1.0",
)

# Allow requests from the frontend (served separately during dev, same origin in prod)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")

# Serve the frontend from /frontend at the root
_frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")

app.mount("/static", StaticFiles(directory=_frontend_dir), name="static")


@app.get("/", include_in_schema=False)
def serve_index():
    return FileResponse(os.path.join(_frontend_dir, "index.html"))


@app.get("/health")
def health():
    return {"status": "ok"}
