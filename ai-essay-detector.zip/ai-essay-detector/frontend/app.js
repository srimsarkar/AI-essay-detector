/**
 * AI Essay Detector — frontend
 *
 * Sends the essay to POST /api/analyze, then renders:
 *   • Highlighted essay with per-sentence colour coding
 *   • Summary chip counts
 *   • Evidence cards for flagged sentences, with SHAP bar visualisation
 */

"use strict";

const API_URL = "/api/analyze";

/* ── DOM refs ───────────────────────────────────────────────────────────── */
const $  = id => document.getElementById(id);
const essayInput     = $("essay-input");
const analyzeBtn     = $("analyze-btn");
const charCount      = $("char-count");
const inputPanel     = $("input-panel");
const resultsPanel   = $("results-panel");
const resetBtn       = $("reset-btn");
const highlightedDiv = $("highlighted-essay");
const overallBadge   = $("overall-badge");
const summaryBar     = $("summary-bar");
const evidenceCards  = $("evidence-cards");
const loadingOverlay = $("loading-overlay");
const errorMsg       = $("error-msg");

/* ── Helpers ────────────────────────────────────────────────────────────── */

function hide(el)  { el.classList.add("hidden"); }
function show(el)  { el.classList.remove("hidden"); }

function labelFromProb(p) {
  if (p >= 0.65) return "ai";
  if (p >= 0.35) return "uncertain";
  return "human";
}

const LABEL_TEXT = { ai: "Likely AI-Generated", uncertain: "Uncertain", human: "Likely Human" };
const LABEL_EMOJI = { ai: "🤖", uncertain: "⚠️", human: "✅" };

function pct(p) { return Math.round(p * 100) + "%"; }

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

/* ── Character counter ──────────────────────────────────────────────────── */
essayInput.addEventListener("input", () => {
  const n = essayInput.value.length;
  charCount.textContent = `${n.toLocaleString()} character${n !== 1 ? "s" : ""}`;
  analyzeBtn.disabled = n < 50;
});

/* ── Analyze ────────────────────────────────────────────────────────────── */
analyzeBtn.addEventListener("click", async () => {
  const essay = essayInput.value.trim();
  if (essay.length < 50) return;

  hide(errorMsg);
  show(loadingOverlay);
  analyzeBtn.disabled = true;

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ essay }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail ?? `Server error ${res.status}`);
    }

    const data = await res.json();
    renderResults(data);
  } catch (err) {
    errorMsg.textContent = `Analysis failed: ${err.message}`;
    show(errorMsg);
    analyzeBtn.disabled = false;
  } finally {
    hide(loadingOverlay);
  }
});

/* ── Reset ──────────────────────────────────────────────────────────────── */
resetBtn.addEventListener("click", () => {
  essayInput.value = "";
  charCount.textContent = "0 characters";
  analyzeBtn.disabled = true;
  hide(resultsPanel);
  show(inputPanel);
  hide(errorMsg);
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ── Render ─────────────────────────────────────────────────────────────── */

function renderResults(data) {
  const oLabel = labelFromProb(data.overall_ai_probability);

  // Overall badge
  overallBadge.className = `overall-badge ${oLabel}`;
  overallBadge.textContent =
    `${LABEL_EMOJI[oLabel]}  ${LABEL_TEXT[oLabel]} — ${pct(data.overall_ai_probability)} AI score`;

  // Summary chips
  renderSummaryBar(data.sentences);

  // Highlighted essay
  renderHighlightedEssay(data.essay, data.sentences);

  // Evidence cards
  renderEvidenceCards(data.sentences);

  hide(inputPanel);
  show(resultsPanel);
  resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ── Summary bar ────────────────────────────────────────────────────────── */

function renderSummaryBar(sentences) {
  const counts = { human: 0, uncertain: 0, ai: 0 };
  for (const s of sentences) counts[s.label]++;

  summaryBar.innerHTML = "";

  const defs = [
    { label: "ai",        text: "AI-flagged" },
    { label: "uncertain", text: "Uncertain" },
    { label: "human",     text: "Human" },
  ];
  for (const { label, text } of defs) {
    if (counts[label] === 0) continue;
    const chip = document.createElement("span");
    chip.className = `summary-chip ${label}`;
    chip.textContent = `${counts[label]} ${text} sentence${counts[label] !== 1 ? "s" : ""}`;
    summaryBar.appendChild(chip);
  }
}

/* ── Highlighted essay ──────────────────────────────────────────────────── */

function renderHighlightedEssay(essay, sentences) {
  highlightedDiv.innerHTML = "";

  // Track all active spans so we can highlight the clicked one
  const allSpans = [];

  let cursor = 0;
  for (const sent of sentences) {
    // Gap (whitespace) between sentences
    if (sent.start_char > cursor) {
      highlightedDiv.appendChild(
        document.createTextNode(essay.slice(cursor, sent.start_char))
      );
    }

    const label = sent.label;
    const span = document.createElement("span");
    span.className = `sent-span ${label}`;
    span.setAttribute("role", "button");
    span.setAttribute("tabindex", "0");
    span.setAttribute("aria-label",
      `${LABEL_TEXT[label]}, ${pct(sent.ai_probability)} AI score: ${sent.sentence}`
    );
    span.title = `${LABEL_TEXT[label]} (${pct(sent.ai_probability)})`;
    span.textContent = sent.sentence;

    // Click / keyboard: scroll to evidence card
    const cardId = `card-${sent.start_char}`;
    function activateCard() {
      // Remove active class from all
      allSpans.forEach(s => s.classList.remove("active-sent"));
      span.classList.add("active-sent");

      const card = document.getElementById(cardId);
      if (card) {
        card.scrollIntoView({ behavior: "smooth", block: "nearest" });
        card.classList.add("card-active");
        setTimeout(() => card.classList.remove("card-active"), 1800);
      }
    }
    span.addEventListener("click", activateCard);
    span.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); activateCard(); }
    });

    highlightedDiv.appendChild(span);
    allSpans.push(span);
    cursor = sent.end_char;
  }

  // Trailing text
  if (cursor < essay.length) {
    highlightedDiv.appendChild(document.createTextNode(essay.slice(cursor)));
  }
}

/* ── Evidence cards ─────────────────────────────────────────────────────── */

function renderEvidenceCards(sentences) {
  evidenceCards.innerHTML = "";

  const flagged = sentences.filter(s => s.label !== "human");

  if (flagged.length === 0) {
    const note = document.createElement("p");
    note.className = "no-flags-note";
    note.textContent = "No sentences were flagged as uncertain or AI-generated.";
    evidenceCards.appendChild(note);
    return;
  }

  for (const sent of flagged) {
    const label   = sent.label;
    const cardId  = `card-${sent.start_char}`;

    const card = document.createElement("div");
    card.className = `evidence-card ${label}`;
    card.id = cardId;

    /* Card header */
    const header = document.createElement("div");
    header.className = "card-header";

    const sentEl = document.createElement("span");
    sentEl.className = "card-sentence";
    sentEl.textContent = `"${sent.sentence}"`;

    const badge = document.createElement("span");
    badge.className = `card-badge ${label}`;
    badge.textContent = `${pct(sent.ai_probability)} AI`;

    header.appendChild(sentEl);
    header.appendChild(badge);
    card.appendChild(header);

    /* Evidence rows */
    const evSection = document.createElement("div");
    evSection.className = "card-evidence";

    if (sent.evidence && sent.evidence.length > 0) {
      // Compute max |shap| for normalising bar widths
      const maxShap = Math.max(...sent.evidence.map(e => Math.abs(e.shap || 0)), 0.001);

      for (const ev of sent.evidence) {
        const row = document.createElement("div");
        row.className = "evidence-row";

        // SHAP bar
        const barWrap = document.createElement("div");
        barWrap.className = "ev-shap-bar-wrap";
        const bar = document.createElement("div");
        bar.className = `ev-shap-bar ${ev.shap >= 0 ? "toward-ai" : "toward-human"}`;
        const barWidth = Math.round(clamp(Math.abs(ev.shap) / maxShap, 0.05, 1) * 38);
        bar.style.width = `${barWidth}px`;
        bar.title = `SHAP: ${ev.shap > 0 ? "+" : ""}${ev.shap.toFixed(3)}`;
        barWrap.appendChild(bar);

        // Signal name
        const signalEl = document.createElement("span");
        signalEl.className = "ev-signal";
        signalEl.textContent = formatSignalName(ev.signal);

        // Explanation
        const expEl = document.createElement("span");
        expEl.className = "ev-explanation";
        expEl.textContent = ev.explanation;

        row.appendChild(barWrap);
        row.appendChild(signalEl);
        row.appendChild(expEl);
        evSection.appendChild(row);
      }
    } else {
      const fallback = document.createElement("p");
      fallback.style.cssText = "color:var(--text-muted);font-size:.85rem;";
      fallback.textContent = "No detailed evidence available for this sentence.";
      evSection.appendChild(fallback);
    }

    card.appendChild(evSection);
    evidenceCards.appendChild(card);
  }
}

/* ── Formatting helpers ─────────────────────────────────────────────────── */

const SIGNAL_LABELS = {
  mean_log_prob:          "Mean log-prob",
  perplexity:             "Perplexity",
  min_token_prob:         "Min token prob",
  perplexity_zscore:      "Perplexity z-score",
  passage_perplexity_std: "Passage PPL std",
  type_token_ratio:       "Type-token ratio",
  rare_word_rate:         "Rare word rate",
  hedging_rate:           "Hedging rate",
  formulaic_count:        "Formulaic phrases",
  sentence_length_tokens: "Length (tokens)",
  sentence_length_chars:  "Length (chars)",
  length_zscore:          "Length z-score",
  first_person_density:   "1st-person density",
  punctuation_variety:    "Punct. variety",
  pos_entropy:            "POS entropy",
  dep_tree_depth:         "Dep. tree depth",
  avg_dep_tree_depth:     "Avg dep. depth",
};

function formatSignalName(raw) {
  return SIGNAL_LABELS[raw] ?? raw.replace(/_/g, " ");
}
