# AI Essay Detector

Detects AI-generated passages in college admissions essays at the sentence level.
Final classification is made by a calibrated gradient-boosted classifier using
17 measurable linguistic signals — not by asking a language model for its opinion.

**i12 HR Drive Hackathon 2026 — Project 2**

---

## Quick Start

```powershell
# 1. Install dependencies (Python 3.13+)
pip install --only-binary=:all: fastapi "uvicorn[standard]" python-multipart spacy nltk `
    scikit-learn numpy pandas pydantic tqdm pytest httpx transformers shap

# 2. Install torch (CPU)
pip install --only-binary=:all: torch --index-url https://download.pytorch.org/whl/cpu

# 3. Download spaCy English model
python -m spacy download en_core_web_sm

# 4. Build dataset and train classifier  (run once; takes ~5 min for GPT-2 scoring)
cd backend
python -m training.build_dataset
python -m training.train

# 5. Start the server
uvicorn main:app --reload

# 6. Open http://localhost:8000 in your browser
```

---

## Running Tests

```powershell
cd ai-essay-detector
pytest                     # full suite (includes slow GPT-2 perplexity tests)
pytest -k "not TestPerplexity"   # fast suite (~40s)
```

---

## Evaluation

```powershell
cd backend
python -m training.evaluate
# → prints metrics to stdout
# → writes docs/evaluation_report.md
```

**Test set results (held-out, n=48):**

| Metric | Value |
|--------|-------|
| Accuracy | 87.5% |
| ROC-AUC | 0.951 |
| Brier score | 0.098 |
| Human precision / recall | 0.875 / 0.875 |
| AI precision / recall | 0.875 / 0.875 |

**Dataset limitations:** This prototype uses 320 sentences (160 human, 160 AI/hybrid)
as a proof-of-concept dataset. A production-quality detector would require a
substantially larger and more diverse dataset (2,000–5,000+ examples across
multiple writing styles, domains, and demographic groups).

---

## Detection Signals

| Group | Features |
|-------|----------|
| **Perplexity** | `mean_log_prob`, `perplexity`, `min_token_prob` (GPT-2 local) |
| **Burstiness** | `perplexity_zscore`, `passage_perplexity_std` |
| **Vocabulary** | `type_token_ratio`, `rare_word_rate`, `hedging_rate`, `formulaic_count` |
| **Style** | `sentence_length_tokens`, `sentence_length_chars`, `length_zscore`, `first_person_density`, `punctuation_variety` |
| **Syntax** | `pos_entropy`, `dep_tree_depth`, `avg_dep_tree_depth` (spaCy) |

---

## Project Structure

```
backend/
  api/routes.py          FastAPI /api/analyze endpoint
  pipeline/
    splitter.py          Sentence segmentation (spaCy / NLTK / naive)
    extractor.py         Feature orchestration
    features/            Per-signal feature modules
    classifier.py        Model loading + inference
    explainer.py         SHAP-based evidence generation
  training/
    seed_data.py         320 labeled training sentences
    build_dataset.py     Feature extraction → features.npz
    train.py             Model training → classifier.pkl
    evaluate.py          Honest evaluation + report generation
  models/classifier.pkl  Trained model bundle
  tests/                 pytest test suite (52 tests)

frontend/
  index.html             Single-page UI
  style.css              Responsive design, colour-coded highlighting
  app.js                 API client, SHAP bar rendering, evidence cards

data/processed/          Feature matrices (generated, not committed)
docs/
  methodology.md         Full signal and architecture documentation
  limitations.md         Honest limitations and failure modes
  evaluation_report.md   Per-class metrics, calibration, wrong examples
```

---

## Design Decisions

- **No LLM judge.** A language model is used only as a measurement instrument
  (GPT-2 perplexity). The final verdict comes from a trained sklearn classifier.
- **Explainability first.** Every flag shows which specific signals fired and
  why, backed by SHAP attributions.
- **Calibrated probabilities.** Platt sigmoid calibration ensures a 70% score
  actually means ~70% confidence, not an uncalibrated logit.
- **ESL awareness.** All signals are used as classifier inputs rather than
  hard thresholds. The model learns which combinations matter, reducing the
  impact of any single signal that may legitimately differ for ESL writers.
- **Honest evaluation.** See `docs/evaluation_report.md` for documented
  failure cases and what this system cannot do.
